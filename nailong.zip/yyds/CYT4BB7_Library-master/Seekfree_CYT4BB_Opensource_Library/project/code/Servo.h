#ifndef SERVO_H
#define SERVO_H

#include "zf_common_headfile.h"

#define SERVO_DUTY(x)         ((float)10000/(1000.0/(float)300)*(0.5+(float)(x)/90.0))

#define  SERVO_LU              (TCPWM_CH09_P05_0)                           //舵机引脚PWM通道
#define  SERVO_LD              (TCPWM_CH10_P05_1)                      
#define  SERVO_RU              (TCPWM_CH11_P05_2)    
#define  SERVO_RD              (TCPWM_CH12_P05_3)   

#define  FREQ                  (300)                                        //舵机频率

#define  SERVO_PWM_MAX_L                (7000)                                //舵机转角最大值PWM
#define  SERVO_PWM_MAX_R                (2000)                                //舵机转角最大值PWM
#define  SERVO_PWM_MIDDLE               (4500)   

/**
* @brief    舵机相关
**/
typedef struct
{
    bool enable;
    uint16_t lu_pwm;
    uint16_t ru_pwm;
    uint16_t ld_pwm;
    uint16_t rd_pwm;
    uint16_t lu_angle;
    uint16_t ru_angle;
    uint16_t ld_angle;
    uint16_t rd_angle;
}ServoStruct;

extern ServoStruct servoStr;
extern float servoLeftFront, servoLeftRear, servoRightFront, servoRightRear;
extern float alphaLeft, betaLeft, alphaRight, betaRight;

extern float XL;
extern float XR;
extern float YL;
extern float YR;
extern float higher_l;
extern float higher_r;
extern float hight;

void Servo_Init(void);
void SERVO_SetPwmValue(void);
void Servo_Angle(float angle);
void Servo_control(float X_left,float X_right,float Y_left,float Y_right);

#endif
