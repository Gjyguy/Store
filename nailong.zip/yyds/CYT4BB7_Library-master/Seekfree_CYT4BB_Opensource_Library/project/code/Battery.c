#include "Battery.h"

float battery_percent;
float battery;
uint16 battery_adc;

/**
* @brief        电池检测电压ADC初始化
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Battery_Init(void)
{
    adc_init(BATTERY_PORT, ADC_10BIT);   
}

/**
* @brief        电池电压计算
* @param
* @ref          参考电压3.3v,电压分压电阻200k和20k
* @author       NaiNong
* @note         
**/
void Battery_Calculate(void) 
{
    battery_adc = adc_mean_filter_convert(BATTERY_PORT, BATTERY_COUNT); 
    battery = ((float)battery_adc / BATTERY_RES) * BATTERY_REF * 
            ((BATTERY_R1 + BATTERY_R2) / BATTERY_R2) + BATTERY_OFFSET;
}

/**
* @brief        电池电压显示
* @param
* @ref          电池电压百分比显示为0-100% 电池电压百分比以绿色显示大于30%的部分 红色显示小于30%的部分
* @author       NaiNong
* @note         
**/
void Battery_Show(void)
{
    battery_percent = (battery - BATTERY_MIN) / (BATTERY_MAX - BATTERY_MIN) * 100.0;

    if (battery_percent < 0)
        battery_percent = 0;

    //ips200_show_string(8 * 5, 16 * 0, "[BATTERY DISPLAY]");

    ips200_draw_line(0, 0, 0, 15, RGB565_BLACK);
    ips200_draw_line(0, 0, 60, 0, RGB565_BLACK);
    ips200_draw_line(0, 15, 60, 15, RGB565_BLACK);
    ips200_draw_line(60, 15, 60, 0, RGB565_BLACK);    
    for (uint8 i = 1; i < 15; i++)
    {
        if (battery_percent > 30)
            ips200_draw_line(1, i, (uint16)(0.6 * battery_percent), i, RGB565_GREEN);
        else
            ips200_draw_line(1, i, (uint16)(0.6 * battery_percent), i, RGB565_RED);
    }
    ips200_show_float(8 * 9, 16 * 0, battery_percent, 3, 2); 
    ips200_show_char(8 * 13, 16 * 0, '%');                     
}