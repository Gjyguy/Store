#ifndef INS_H
#define INS_H

#include "zf_common_headfile.h"

#define MILEAGE             (2000)                      //里程计
#define MAXSIZE             (500)                       //flash存储的最大页面
#define READ_MAXSIZE        (10000)                     //最大读取设置

#define TURN_DELTA_MAX      (20)         

/**
 * @brief 科目一惯导场景状态
 */
typedef enum {
    INS_RTS_NONE = 0,               // 无
    INS_RTS_STRAIGHT_1,             // 前进直线（第一段）
    INS_RTS_STRAIGHT_2,             // 掉头直线（第二段）
    INS_RTS_SLALOM,                 // 绕桩
    INS_RTS_STRAIGHT_3,             // 冲刺直线（第三段）
    INS_RTS_FINISH,                 // 结束    
}INS_Rts_Step;

/**
* @brief    科目一惯导相关
**/
typedef struct {
    bool enable;                //科目一使能
    bool save;               
    uint16 time;
    uint16 distance1;
    uint16 distance2;    
    uint16 distance3;     
}INS_RtsStruct;

typedef struct{
    uint16 Counter;                                     //计数器
    uint16 size;                                        //每页数据的个数
    uint8 Flash_page_index;                             //flash页面索引
    uint32 number;
    uint32 index;                                       //惯导复现索引
    uint8 prospect;                                     //惯导前瞻
    float last_yaw;
    float Ins_read[READ_MAXSIZE];                       //读取数据缓存区
}InsStruct;

extern INS_Rts_Step INS_rts_step;
extern INS_RtsStruct INS_rtsStr;

extern InsStruct InsStr;  

void Ins_Init(void);
void Ins_Save(void);
void Ins_Read(void);
void Ins_Run(void);
void Ins_Rts_Save(void);
void Ins_Show(void);

#endif