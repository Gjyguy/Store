#include "Rts.h"

Rts_Step rts_step = RTS_NONE;
RtsStruct rtsStr;
float raw_target = 0;

/**
* @brief        科目一参数初始化
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void Rts_Init(void)
{
    rtsStr.enable = false;
    rtsStr.Counter = 0;
    rtsStr.time = 0;
}

/**
* @brief        Round_Trip_Slalom
* @param
* @ref          前行直道和返回绕桩
* @author       NaiNong
* @note         
**/
void Rts_process(void)
{
    switch (rts_step)
    {
        case RTS_NONE:
        {
            if(rtsStr.enable)
            {
                rtsStr.time++;
                if(rtsStr.time > 300)
                {
                    Buzzer_Enable(BuzzerOk); 
                    rtsStr.time = 0;
                    turn.target = imu660rc_yaw;  
                    rts_step = RTS_STRAIGHT_1;
                } 
            }
            break;
        } 

        case RTS_STRAIGHT_1:
        {
            motorStr.Integral = true;
            turn.enable = true;
            turn_v.enable = true;

            if(InsStr.Counter > INS_rtsStr.distance1 -10)
                speedctrl.target = 0;
            else
                speedctrl.target = speedctrl.straight1;

            if(InsStr.Counter > INS_rtsStr.distance1)
            {
                Buzzer_Enable(BuzzerDing);
                motorStr.Integral = false;
                turn.target = imu660rc_yaw;
                raw_target = turn.target + 180.0f;
                if (raw_target > 180.0f)
                    raw_target -= 360.0f;
                else if (raw_target < -180.0f)
                    raw_target += 360.0f;

                rts_step = RTS_TURN;
            }
            break;
        }

        case RTS_TURN:
        {
            speedctrl.target = 0;
            turn.target += 1.5f;

            if (fabsf(raw_target - imu660rc_yaw) < 3.0f) 
            {
                Buzzer_Enable(BuzzerDing);
                turn.target = raw_target;
                rts_step = RTS_STRAIGHT_2;
            }
            break;
        }  

        case RTS_STRAIGHT_2:
        {
            motorStr.Integral = true;
            speedctrl.target = speedctrl.straight2;
            if(InsStr.Counter > INS_rtsStr.distance2)
            {
                Buzzer_Enable(BuzzerDing);
                motorStr.Integral = false;
                rts_step = RTS_SLALOM;
            }
            break;
        } 

        case RTS_SLALOM:
        {
            motorStr.Integral = true;
            speedctrl.target = speedctrl.slalom;
            if(InsStr.index >= (InsStr.number-InsStr.prospect))
            {
                Buzzer_Enable(BuzzerDing);
                motorStr.Integral = false;
                turn.target = raw_target; 
                rts_step = RTS_STRAIGHT_3;
            } 
            break;
        } 

        case RTS_STRAIGHT_3:
        {
            motorStr.Integral = true;
            speedctrl.target = speedctrl.straight3;
            if(InsStr.Counter > INS_rtsStr.distance3)
            {
                Buzzer_Enable(BuzzerDing);
                motorStr.Integral = false;
                rts_step = RTS_FINISH;
            }
            break;
        } 

        case RTS_FINISH:
        {
            Buzzer_Enable(BuzzerOk);
            turn.enable = false;
            turn_v.enable = false;
            speedctrl.target = -100;
            rtsStr.enable = false;
            rts_step = RTS_NONE;
            break;
        } 
    }
}

/**
* @brief       科目一数据显示
* @param
* @ref
* @author       NaiNong
* @note
**/
void Rts_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[RTS DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "enable:");
    ips200_show_int(8 * 15, 16 * 1 ,rtsStr.enable, 4);

    ips200_show_string(8 * 0, 16 * 2, "step:");
    ips200_show_int(8 * 15, 16 * 2 ,rts_step, 4);

    ips200_show_string(8 * 0, 16 * 3, "yaw:");
    ips200_show_float(8 * 15, 16 * 3,imu660rc_yaw, 3, 2); 

}