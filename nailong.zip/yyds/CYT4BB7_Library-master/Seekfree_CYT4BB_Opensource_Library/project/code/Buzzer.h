#ifndef BUZZER_H
#define BUZZER_H

#include "zf_common_headfile.h"

#define BUZZER              (P19_4)                             //蜂鸣器引脚

#define BUZZER_ON           (gpio_set_level(BUZZER, 1))         //蜂鸣器开启
#define BUZZER_OFF          (gpio_set_level(BUZZER, 0))         //蜂鸣器关闭
#define BUZZER_REV          (gpio_toggle_level(BUZZER))         //蜂鸣器翻转

/**
* @brief    蜂鸣器音效
**/
typedef enum {
    BuzzerOk = 0,                       //确认提示音
    BuzzerWarning,                      //报警提示音
    BuzzerSysStart,                     //开机提示音
    BuzzerDing,                         //叮=====(￣▽￣*)
    BuzzerFinish,                       //结束提示音
}BuzzerEnum;

/**
* @brief    蜂鸣器相关
**/
typedef struct {
    bool Enable;                        //使能标志
    uint16 Times;                       //鸣叫次数
    uint16 Counter;                     //计数器
    uint16 Cut;                         //间隔时间
    bool Silent;                        //是否禁用蜂鸣器
}BuzzerStruct;

extern BuzzerStruct buzzerStr;          //蜂鸣器结构体

//外部函数声明
void Buzzer_Init(void);                 //蜂鸣器初始化
void Buzzer_Timer(void);                //Buzzer线程控制器
void Buzzer_Handle(void);               //Buzzer逻辑处理函数
void Buzzer_Enable(BuzzerEnum buzzer);  //蜂鸣器使能

#endif