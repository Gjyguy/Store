#ifndef Key_H
#define Key_H

#include "zf_common_headfile.h"

#define KEY1                (P20_0)                         //按键1引脚
#define KEY2                (P20_1)                         //按键2引脚
#define KEY3                (P20_2)                         //按键3引脚
#define KEY4                (P20_3)                         //按键4引脚
#define KEY5                (P21_5)                         //按键5引脚

#define KEY1_GET            (gpio_get_level(KEY1))          //获取按键1电平状态
#define KEY2_GET            (gpio_get_level(KEY2))          //获取按键2电平状态
#define KEY3_GET            (gpio_get_level(KEY3))          //获取按键3电平状态
#define KEY4_GET            (gpio_get_level(KEY4))          //获取按键4电平状态
#define KEY5_GET            (gpio_get_level(KEY5))          //获取按键5电平状态

/**
* @brief    按键枚举状态
**/
typedef enum {
    KEY_RELEASED = 0,           // 按键未按下
    KEY_PRESSED,                // 按键按下
}KeyEnum;

/**
* @brief    按键相关
**/
typedef struct {
    KeyEnum state;          // 当前按键状态
    uint8 status;           // 当前按键电平状态
    uint8 last_status;      // 上一次按键电平状态
}KeyStruct;

extern KeyStruct Key1;
extern KeyStruct Key2;
extern KeyStruct Key3;
extern KeyStruct Key4;
extern KeyStruct Key5;

//内部函数声明
void Key1_Handle(void);         //按键1状态处理
void Key2_Handle(void);         //按键2状态处理
void Key3_Handle(void);         //按键3状态处理
void Key4_Handle(void);         //按键4状态处理
void Key5_Handle(void);         //按键5状态处理

void key_up(void);              //菜单上移
void key_down(void);            //菜单下移
void key_enter(void);           //菜单进入
void key_quit(void);            //菜单退出
void key_select(void);          //菜单选择/调参

void key_SetupCtrl_Plus(void);  //菜单步进值增加
void key_SetupCtrl_Sub(void);   //菜单步进值减少
void key_plus(void);            //菜单数值增加
void key_sub(void);             //菜单数值减少

//外部函数声明
void Key_Init(void);            //按键初始化
void Key_Handle(void);          //按键状态获取与处理

#endif