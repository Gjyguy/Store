#include "Servo.h"

ServoStruct servoStr;

float alphaLeftToAngle, betaLeftToAngle, alphaRightToAngle, betaRightToAngle;
float alphaLeft, betaLeft, alphaRight, betaRight;
float aLeft, bLeft, cLeft, dLeft, eLeft, fLeft;
float aRight, bRight, cRight, dRight, eRight, fRight;
float alpha1, alpha2, beta1, beta2;
float L1 = 60, L2 = 90, L3 = 90, L4 = 60, L5 = 37;
float servoLeftFront, servoLeftRear, servoRightFront, servoRightRear;

float XL=0;
float XR=0;
float YL=0;
float YR=0;

float XLeft, XRight,YLeft,YRight;

float X_L = 18.5;
float Y_L = 30;
float X_R = 18.5;
float Y_R = 30;

float hight=0;
/**
* @brief        舵机初始化
* @param        
* @ref
* @author       NaiNong
* @note
**/
void Servo_Init(void)
{
    servoStr.enable=true;
    servoStr.lu_pwm=3875;
    servoStr.ld_pwm=5127;
    servoStr.ru_pwm=5124;
    servoStr.rd_pwm=3872;
  
    pwm_init(SERVO_LU, FREQ, servoStr.lu_pwm);
    pwm_init(SERVO_LD, FREQ, servoStr.ld_pwm);
    pwm_init(SERVO_RU, FREQ, servoStr.ru_pwm);
    pwm_init(SERVO_RD, FREQ, servoStr.rd_pwm);   
}

/**
* @brief        舵机输出PWM设置
* @param        pwm：-200~200
* @ref
* @author       NaiNong
* @note
**/
void SERVO_SetPwmValue(void)
{
    servoStr.lu_pwm=(uint32)SERVO_DUTY(servoLeftRear);
    servoStr.ld_pwm=(uint32)SERVO_DUTY(servoLeftFront);
   
    servoStr.ru_pwm=(uint32)SERVO_DUTY(servoRightRear);
    servoStr.rd_pwm=(uint32)SERVO_DUTY(servoRightFront);
    
    if(servoStr.lu_pwm < SERVO_PWM_MAX_R)
        servoStr.lu_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.lu_pwm > SERVO_PWM_MAX_L)
        servoStr.lu_pwm = SERVO_PWM_MAX_L;

    if(servoStr.ru_pwm < SERVO_PWM_MAX_R)
        servoStr.ru_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.ru_pwm > SERVO_PWM_MAX_L)
        servoStr.ru_pwm = SERVO_PWM_MAX_L;
    
    if(servoStr.ld_pwm < SERVO_PWM_MAX_R)
        servoStr.ld_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.ld_pwm > SERVO_PWM_MAX_L)
        servoStr.ld_pwm = SERVO_PWM_MAX_L;

    if(servoStr.rd_pwm < SERVO_PWM_MAX_R)
        servoStr.rd_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.rd_pwm > SERVO_PWM_MAX_L)
        servoStr.rd_pwm = SERVO_PWM_MAX_L;    

    pwm_set_duty(SERVO_LU,servoStr.lu_pwm);
    pwm_set_duty(SERVO_RU,servoStr.ru_pwm);
    pwm_set_duty(SERVO_LD,servoStr.ld_pwm);
    pwm_set_duty(SERVO_RD,servoStr.rd_pwm);

}

/**
* @brief        舵机输出角度设置
* @param       angle
* @ref
* @author       NaiNong
* @note
**/
void Servo_Angle(float angle)
{
    servoStr.lu_pwm=(uint32)SERVO_DUTY(angle);
    servoStr.ld_pwm=(uint32)SERVO_DUTY(180-angle);
   
    servoStr.ru_pwm=(uint32)SERVO_DUTY(180-angle);
    servoStr.rd_pwm=(uint32)SERVO_DUTY(angle);
  
    if(servoStr.lu_pwm < SERVO_PWM_MAX_R)
        servoStr.lu_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.lu_pwm > SERVO_PWM_MAX_L)
        servoStr.lu_pwm = SERVO_PWM_MAX_L;

    if(servoStr.ru_pwm < SERVO_PWM_MAX_R)
        servoStr.ru_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.ru_pwm > SERVO_PWM_MAX_L)
        servoStr.ru_pwm = SERVO_PWM_MAX_L;
    
    if(servoStr.ld_pwm < SERVO_PWM_MAX_R)
        servoStr.ld_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.ld_pwm > SERVO_PWM_MAX_L)
        servoStr.ld_pwm = SERVO_PWM_MAX_L;

    if(servoStr.rd_pwm < SERVO_PWM_MAX_R)
        servoStr.rd_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.rd_pwm > SERVO_PWM_MAX_L)
        servoStr.rd_pwm = SERVO_PWM_MAX_L;    

    pwm_set_duty(SERVO_LU,servoStr.lu_pwm);
    pwm_set_duty(SERVO_RU,servoStr.ru_pwm);
    pwm_set_duty(SERVO_LD,servoStr.ld_pwm);
    pwm_set_duty(SERVO_RD,servoStr.rd_pwm);
}

/**
* @brief        舵机输出PWM设置
* @param        pwm：-200~200
* @ref
* @author       NaiNong
* @note
**/
void Servo_control(float X_left,float X_right,float Y_left,float Y_right)
{   
    // 输入限幅
    if (Y_left <= 0)Y_left = 0;
    if (Y_right <= 0)Y_right = 0;
    if (Y_left >= 100)Y_left = 100;
    if (Y_right >= 100)Y_right = 100;
    
    //X_left=XL;
    //X_right=XR;
    //Y_left=YL;
    //Y_right=YR;
    
    XLeft = X_L + 0.01 * (X_left+18.5 - X_L);
    XRight = X_R + 0.01 * (X_right+18.5 - X_R);
    YLeft = Y_L + 0.01 * (Y_left+30 - Y_L);
    YRight = Y_R + 0.01 * (Y_right+30 - Y_R);
    
    X_L = XLeft;
    Y_L = YLeft;
    X_R = XRight;
    Y_R = YRight;
    
        //左腿计算
    aLeft = 2 * XLeft * L1;
    bLeft = 2 * YLeft * L1;
    cLeft = XLeft * XLeft + YLeft * YLeft + L1 * L1 - L2 * L2;

    dLeft = 2 * L4 * (XLeft - L5);
    eLeft = 2 * L4 * YLeft;
    fLeft = ((XLeft - L5) * (XLeft - L5) + YLeft * YLeft + L4 * L4  - L3 * L3);

    alpha1 = 2 * atan((bLeft + sqrt((aLeft * aLeft) + (bLeft * bLeft) - (cLeft * cLeft))) / (aLeft + cLeft));
    alpha2 = 2 * atan((bLeft - sqrt((aLeft * aLeft) + (bLeft * bLeft) - (cLeft * cLeft))) / (aLeft + cLeft));

    beta1 = 2 * atan((eLeft + sqrt((dLeft * dLeft) + eLeft * eLeft - (fLeft * fLeft))) / (dLeft + fLeft));
    beta2 = 2 * atan((eLeft - sqrt((dLeft * dLeft) + eLeft * eLeft - (fLeft * fLeft))) / (dLeft + fLeft));

    alpha1 = (alpha1 >= 0) ? alpha1 : (alpha1 + 2 * PI);
    alpha2 = (alpha2 >= 0) ? alpha2 : (alpha2 + 2 * PI);
    
    if (alpha1 >= PI / 4) 
        alphaLeft = alpha1;
    else 
        alphaLeft = alpha2;

    if (beta1 >= 0 && beta1 <= PI / 4) 
        betaLeft = beta1;
    else 
        betaLeft = beta2;

    alphaLeftToAngle = (alphaLeft / 3.14) * 180;
    betaLeftToAngle = (betaLeft / 3.14) * 180;

    //右腿计算
    aRight = 2 * XRight * L1;
    bRight = 2 * YRight * L1;
    cRight = XRight * XRight + YRight * YRight + L1 * L1 - L2 * L2;
    dRight = 2 * L4 * (XRight - L5);
    eRight = 2 * L4 * YRight;
    fRight = ((XRight - L5) * (XRight - L5) + L4 * L4 + YRight * YRight - L3 * L3);

    alpha1 = 2 * atan((bRight + sqrt((aRight * aRight) + (bRight * bRight) - (cRight * cRight))) / (aRight + cRight));
    alpha2 = 2 * atan((bRight - sqrt((aRight * aRight) + (bRight * bRight) - (cRight * cRight))) / (aRight + cRight));
    beta1 = 2 * atan((eRight + sqrt((dRight * dRight) + eRight * eRight - (fRight * fRight))) / (dRight + fRight));
    beta2 = 2 * atan((eRight - sqrt((dRight * dRight) + eRight * eRight - (fRight * fRight))) / (dRight + fRight));

    alpha1 = (alpha1 >= 0) ? alpha1 : (alpha1 + 2 * PI);
    alpha2 = (alpha2 >= 0) ? alpha2 : (alpha2 + 2 * PI);

    if (alpha1 >= PI / 4) 
        alphaRight = alpha1;
    else 
        alphaRight = alpha2;
    if (beta1 >= 0 && beta1 <= PI / 4)
        betaRight = beta1;
    else 
        betaRight = beta2;

    alphaRightToAngle = (alphaRight / 3.14) * 180;
    betaRightToAngle = (betaRight / 3.14) * 180;
    
    servoLeftFront = 90 - (180-alphaLeftToAngle);
    servoLeftRear = 180 - (90 - betaLeftToAngle);
    servoRightFront = 180 - (alphaRightToAngle - 90);
    servoRightRear = 180 - (90 + betaRightToAngle);
    
    SERVO_SetPwmValue();
}