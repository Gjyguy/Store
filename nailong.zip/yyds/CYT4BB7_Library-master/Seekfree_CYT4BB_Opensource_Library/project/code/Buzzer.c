#include "Buzzer.h"

BuzzerStruct buzzerStr;

/**
* @brief        Buzzer外设初始化
* @param
* @ref
* @author       NaiNong
* @note         外设：蜂鸣器 
**/
void Buzzer_Init(void)
{
    gpio_init(BUZZER, GPO, 0, GPO_PUSH_PULL); 
    
    buzzerStr.Counter = 0;        //计数器
    buzzerStr.Cut = 0;            //间隔时间
    buzzerStr.Times = 0;          //鸣叫次数
    buzzerStr.Enable = false;     //使能 
    buzzerStr.Silent = false;     //禁用
}

/**
* @brief        Buzzer线程控制器
* @param
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Timer(void)
{
    //蜂鸣器控制
    if(buzzerStr.Enable)
    {
        buzzerStr.Counter++;

        if(buzzerStr.Counter>buzzerStr.Cut)
            buzzerStr.Counter = buzzerStr.Cut;
    }
}

/**
* @brief        Buzzer逻辑处理函数
* @param
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Handle(void)
{
    //蜂鸣器控制
    if(buzzerStr.Enable && !buzzerStr.Silent)
    {
        if(buzzerStr.Times<=0)
        {
            BUZZER_OFF;
            buzzerStr.Enable = false;
            return;
        }
        else if(buzzerStr.Cut <= buzzerStr.Counter)
        {
            BUZZER_REV;
            buzzerStr.Times--;
            buzzerStr.Counter = 0;
        }
    }
}

/**
* @brief        蜂鸣器使能
* @param        buzzer：蜂鸣器工作模式
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Enable(BuzzerEnum buzzer)
{
    switch(buzzer)
    {
        case BuzzerOk:
            buzzerStr.Cut = 200;         //200ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 2;
            break;

        case BuzzerWarning:
            buzzerStr.Cut = 100;        //100ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 10;
            break;

        case BuzzerSysStart:
            buzzerStr.Cut = 500;         //60ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 2;
            break;

        case BuzzerDing:
            buzzerStr.Cut = 50;         //50ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 2;
            break;

        case BuzzerFinish:
            buzzerStr.Cut = 500;        //200ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 2;
            break;
    }
    buzzerStr.Counter = 0;
}
