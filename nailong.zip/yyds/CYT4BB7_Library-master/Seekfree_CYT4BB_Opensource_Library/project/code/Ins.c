#include "Ins.h"

INS_Rts_Step INS_rts_step = INS_RTS_NONE;
INS_RtsStruct INS_rtsStr;

InsStruct InsStr;    

/**
* @brief        惯导初始化
* @param
* @ref
* @author       NaiNong
* @note        
**/
void Ins_Init(void)
{ 
    InsStr.Counter = 0;                 
    InsStr.size = 0;
    InsStr.Flash_page_index = FLASH_PAGE_INS;
    InsStr.index = 0;
    InsStr.prospect = 0;
    InsStr.last_yaw = 0;

    flash_buffer_clear();
}

/**
* @brief        惯导采集保存
* @param
* @ref
* @author       NaiNong
* @note        
**/
void Ins_Save(void)
{
    if(InsStr.size >= MAXSIZE)
    {
        Flash_Write(InsStr.Flash_page_index, InsStr.size);
        InsStr.size = 0;
        InsStr.Flash_page_index++;
        zf_assert(InsStr.Flash_page_index < FLASH_PAGE_MAX);//防止越界报错
    }

    if(motorStr.Distance >= MILEAGE)
    {
        float delta = imu660rc_yaw - InsStr.last_yaw;
        // 将差值归一化到 [-180, 180) 区间，避免边界跳跃
        if (delta > 180.0f) delta -= 360.0f;
        else if (delta < -180.0f) delta += 360.0f;
        flash_union_buffer[InsStr.size].float_type = delta;
        InsStr.size++;
        InsStr.number++;
        InsStr.last_yaw = imu660rc_yaw;   // 更新上次角度
        motorStr.Distance -= MILEAGE; 
    }
    else if(motorStr.Distance <= -MILEAGE) 
    {
        motorStr.Distance += MILEAGE;     
    }
}

/**
* @brief        惯导读取
* @param
* @ref
* @author       NaiNong
* @note        
**/
void Ins_Read(void)
{
    if (InsStr.number == 0) {
        return;  // 没有数据可读
    }

    uint16 total_pages = (InsStr.number + MAXSIZE - 1) / MAXSIZE;  // 总页数向上取整
    uint16 remaining = InsStr.number;                              // 剩余未读数据个数
    uint16 dest_index = 0;                                         // Ins_read 数组的写入索引
    uint8 start_page = FLASH_PAGE_INS;                             // 数据存储的起始页

    for (uint16 page = 0; page < total_pages; page++) {
        // 当前页要读取的数据个数（最后一页可能不满 MAXSIZE）
        uint16 count = (remaining > MAXSIZE) ? MAXSIZE : remaining;

        // 从 Flash 中读取一页数据到 flash_union_buffer
        Flash_Read(start_page + page, count);

        // 将 buffer 中的 float 数据复制到 Ins_read 数组
        for (uint16 i = 0; i < count; i++) {
            InsStr.Ins_read[dest_index++] = flash_union_buffer[i].float_type;
        }

        remaining -= count;
    }
}

/**
* @brief        惯导复现
* @param
* @ref
* @author       NaiNong
* @note        
**/
void Ins_Run(void)
{
    if(motorStr.Distance >= MILEAGE)
    {
        /*
        float delta = InsStr.Ins_read[InsStr.index + InsStr.prospect];
 
        if (delta > TURN_DELTA_MAX) {
            delta = TURN_DELTA_MAX;
        } else if (delta < -TURN_DELTA_MAX) {
            delta = -TURN_DELTA_MAX;
        }
        turn.target += delta;
*/
turn.target += InsStr.Ins_read[InsStr.index + InsStr.prospect];
        if(InsStr.index >= (InsStr.number-InsStr.prospect))
            InsStr.index = (InsStr.number-InsStr.prospect);
        else
            InsStr.index++;
            
        motorStr.Distance -= MILEAGE; 
    }
    else if(motorStr.Distance <= -MILEAGE) 
    {
        motorStr.Distance += MILEAGE;     
    }
}

/**
* @brief        科目一保存
* @param
* @ref
* @author       NaiNong
* @note        
**/
void Ins_Rts_Save(void)
{
    switch (INS_rts_step)
    {
        case INS_RTS_NONE:
        {
            if(INS_rtsStr.enable)
            {
                InsStr.number = 0;
                INS_rtsStr.distance1 = 0;
                INS_rtsStr.distance2 = 0;
                INS_rtsStr.distance3 = 0; 

                displaystr.Ins = true;
                INS_rtsStr.time++;
                if(INS_rtsStr.time > 100)
                {
                    Buzzer_Enable(BuzzerOk); 
                    INS_rtsStr.time = 0;
                    INS_rts_step = INS_RTS_STRAIGHT_1;
                } 
            }
            break;
        } 

        case INS_RTS_STRAIGHT_1:
        {
            motorStr.Integral = true;
            if(INS_rtsStr.save)
            {
                INS_rtsStr.time++;
                INS_rtsStr.distance1 = InsStr.Counter;                
                if(INS_rtsStr.time > 100)
                {
                    Buzzer_Enable(BuzzerOk); 
                    INS_rtsStr.time = 0;
                    INS_rtsStr.save = false;    
                    motorStr.Integral = false; 
                    INS_rts_step = INS_RTS_STRAIGHT_2;
                }      
            }
            break;
        }

        case INS_RTS_STRAIGHT_2:
        {
            motorStr.Integral = true;
            if(INS_rtsStr.save)
            {
                INS_rtsStr.time++;
                INS_rtsStr.distance2 = InsStr.Counter;                     
                if(INS_rtsStr.time > 100)
                {
                    Buzzer_Enable(BuzzerOk); 
                    INS_rtsStr.time = 0;
                    INS_rtsStr.save = false;
                    motorStr.Integral = false; 
                    InsStr.last_yaw = imu660rc_yaw;
                    INS_rts_step = INS_RTS_SLALOM;
                }      
            }
            break;
        }

        case INS_RTS_SLALOM:
        {
            motorStr.Integral = true;
            
            if(INS_rtsStr.save)
            {
                Buzzer_Enable(BuzzerOk);
                Flash_Write(InsStr.Flash_page_index, InsStr.size); 
                INS_rtsStr.save = false;
                motorStr.Integral = false; 
                INS_rts_step = INS_RTS_STRAIGHT_3;       
            }
            break;
        }

        case INS_RTS_STRAIGHT_3:
        {
            motorStr.Integral = true;
            if(INS_rtsStr.save)
            {
                INS_rtsStr.time++;
                INS_rtsStr.distance3 = InsStr.Counter;                     
                if(INS_rtsStr.time > 100)
                {
                    Buzzer_Enable(BuzzerOk); 
                    INS_rtsStr.time = 0;
                    INS_rtsStr.save = false;
                    motorStr.Integral = false; 
                    INS_rts_step = INS_RTS_FINISH;
                }      
            }
            break;
        }

        case INS_RTS_FINISH:
        {
            Flash_Param_Write();
            INS_rtsStr.enable = false;
            INS_rts_step = INS_RTS_NONE;
            break;
        }

    }
}

/**
* @brief      惯导数据显示
* @param
* @ref
* @author       NaiNong
* @note
**/
void Ins_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[INS DISPLAY]");
    
    ips200_show_string(8 * 0, 16 * 1, "yaw:");
    ips200_show_float(8 * 15, 16 * 1,imu660rc_yaw, 3, 2); 
    
    //科目一数据显示
    ips200_show_string(8 * 8, 16 * 2, "[RTS DISPLAY]");

    ips200_show_string(8 * 0, 16 * 3, "time:");
    ips200_show_int(8 * 15, 16 * 3,INS_rtsStr.time ,4);

    ips200_show_string(8 * 0, 16 * 4, "enable:");
    ips200_show_int(8 * 15, 16 * 4,INS_rtsStr.enable ,1); 
    
    ips200_show_string(8 * 0, 16 * 5, "check:");
    ips200_show_int(8 * 15, 16 * 5,flashStr.check ,3); 
    
    ips200_show_string(8 * 0, 16 * 6, "step:");
    ips200_show_int(8 * 15, 16 * 6,INS_rts_step ,1); 

    ips200_show_string(8 * 0, 16 * 7, "Distance:");
    ips200_show_int(8 * 15, 16 * 7,motorStr.Distance ,5);

    ips200_show_string(8 * 0, 16 * 8, "Counter:");
    ips200_show_int(8 * 15, 16 * 8,InsStr.Counter ,5); 

    ips200_show_string(8 * 0, 16 * 9, "distance1:");
    ips200_show_int(8 * 15, 16 * 9,INS_rtsStr.distance1 ,5);

    ips200_show_string(8 * 0, 16 * 10, "distance2:");
    ips200_show_int(8 * 15, 16 * 10,INS_rtsStr.distance2 ,5);

    ips200_show_string(8 * 0, 16 * 11, "distance3:");
    ips200_show_int(8 * 15, 16 * 11,INS_rtsStr.distance3 ,5);

    ips200_show_string(8 * 0, 16 * 12, "page:");
    ips200_show_int(8 * 15, 16 * 12,InsStr.Flash_page_index ,3);

    ips200_show_string(8 * 0, 16 * 13, "number:");
    ips200_show_int(8 * 15, 16 * 13,InsStr.number ,5);

    ips200_show_string(8 * 0, 16 * 14, "size:");
    ips200_show_int(8 * 15, 16 * 14,InsStr.size ,4);

}