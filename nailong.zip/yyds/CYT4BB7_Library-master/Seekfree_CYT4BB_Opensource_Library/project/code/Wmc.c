#include "Wmc.h"

Spin_Step spin_step = none;
SpinStruct spinStr;

bool spin_enable = false;
float target_angle = 720;       // 旋转两圈
float stop_tolerance = 20;      // 停止容差

/**
* @brief        Waypoint_Mine_Clear
* @param
* @ref          定点排雷
* @author       NaiNong
* @note         
**/
void Wmc_process(void)
{
    Spin_process();
}

/**
* @brief        旋转两圈
* @param
* @ref          定点排雷
* @author       NaiNong
* @note         
**/
void Spin_process(void)
{
    switch (spin_step)
    {
        case none:
        {
            if (spin_enable)
            {    
                Buzzer_Enable(BuzzerSysStart); 
                spinStr.last_yaw = imu660rc_yaw;                
                
                spin_step = spin;
            }        
            break;
        }

        case spin:
        {
            // 1. 计算原始差值
            spinStr.delta = imu660rc_yaw - spinStr.last_yaw;
            
            // 2. 处理 ±180° 跳变
            if (spinStr.delta > 180)
                spinStr.delta -= 360;
            else if (spinStr.delta < -180)
                spinStr.delta += 360;
            
            // 3. 累加总旋转角度
            if(spinStr.left)
            {
                spinStr.total_yaw -= spinStr.delta;
                spinStr.out = -500;
            }
            else
            {
                spinStr.total_yaw += spinStr.delta;
                spinStr.out = 500;
            }
            
            // 4. 更新上一次的角度
            spinStr.last_yaw = imu660rc_yaw;
            
            // 5. 计算误差
            spinStr.error = target_angle - spinStr.total_yaw;
            
            if(fabs(spinStr.error) <= stop_tolerance)
            {
                spinStr.out = 0;
                spin_step = finish;
            }     
            break;
        }

        case finish:
        {
            Buzzer_Enable(BuzzerDing);
            spin_enable = false;

            spinStr.last_yaw = 0;
            spinStr.total_yaw = 0;
            spinStr.delta = 0;
            spinStr.error = 0;

            spin_step = none;
            break;
        }
    }
}

void Wmc_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[WMC DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "enable:");
    ips200_show_int(8 * 15, 16 * 1,spin_enable, 1);

    ips200_show_string(8 * 0, 16 * 2, "step:");
    ips200_show_int(8 * 15, 16 * 2,spin_step, 1); 
    
    ips200_show_string(8 * 0, 16 * 4, "now_yaw:");
    ips200_show_float(8 * 15, 16 * 4,imu660rc_yaw, 3, 2); 

    ips200_show_string(8 * 0, 16 * 3, "last_yaw:");
    ips200_show_float(8 * 15, 16 * 3,spinStr.last_yaw, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 5, "total_yaw:");
    ips200_show_float(8 * 15, 16 * 5,spinStr.total_yaw, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 6, "error_yaw:");
    ips200_show_float(8 * 15, 16 * 6,spinStr.error, 3, 2); 

    ips200_show_string(8 * 0, 16 * 7, "delta:");
    ips200_show_float(8 * 15, 16 * 7,spinStr.delta, 3, 2); 

    ips200_show_string(8 * 0, 16 * 8, "out:");
    ips200_show_int(8 * 15, 16 * 8 ,spinStr.out, 4);
}