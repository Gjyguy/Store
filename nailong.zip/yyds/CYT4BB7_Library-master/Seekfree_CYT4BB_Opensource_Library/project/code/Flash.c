#include "Flash.h"

FlashStruct flashStr;

/**
* @brief        Flash初始化
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Init(void)
{
    flash_init();

    flashStr.sub1_save = false;
    flashStr.check = 0;
}

/**
* @brief        Flash读取
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Read(uint8 page_index, uint16 len)
{
    flash_buffer_clear();
    if(flash_check(FLASH_SECTION_INDEX, page_index))
    {        
        flash_read_page_to_buffer(FLASH_SECTION_INDEX, page_index, len);
    }
}

/**
* @brief        Flash写入
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Write(uint8 page_index, uint16 len)
{
    if(flash_check(FLASH_SECTION_INDEX, page_index))                            // 判断是否有数据
    {     
        flash_erase_page(FLASH_SECTION_INDEX, page_index);                      // 擦除原先数据
    } 
    flashStr.check++;
    flash_write_page_from_buffer(FLASH_SECTION_INDEX, page_index, len);         //将缓冲区的数据写入flash中
    flash_buffer_clear();
}

/**
* @brief        Flash参数读取
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Param_Read(void)
{
    flash_buffer_clear();
    if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM))                            // 判断是否有数据
    {     
        flash_read_page_to_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM, 4+rtsStr.cone-1);
        InsStr.number = flash_union_buffer[0].uint32_type;
        INS_rtsStr.distance1 = flash_union_buffer[1].uint16_type;
        INS_rtsStr.distance2 = flash_union_buffer[2].uint16_type;
        INS_rtsStr.distance3 = flash_union_buffer[3].uint16_type;      
        
        for(int i = 0; i < (rtsStr.cone-1); i++)
        {
            INS_rtsStr.cone_distance[i] = flash_union_buffer[i+4].uint16_type;
        }
    } 
}

/**
* @brief        Flash参数写入
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Param_Write(void)
{
    if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM))                            // 判断是否有数据
    {     
        flash_erase_page(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM);                      // 擦除原先数据
    } 
    flashStr.check++;

    flash_union_buffer[0].uint32_type = InsStr.number;
    flash_union_buffer[1].uint16_type = INS_rtsStr.distance1;
    flash_union_buffer[2].uint16_type = INS_rtsStr.distance2;
    flash_union_buffer[3].uint16_type = INS_rtsStr.distance3;

    for(int i = 0; i < (rtsStr.cone-1); i++)
    {
        flash_union_buffer[i+4].uint16_type = INS_rtsStr.cone_distance[i];
    }
    
    flash_write_page_from_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM, 4+rtsStr.cone-1);         //将缓冲区的数据写入flash中
    flash_buffer_clear();
}

/**
* @brief        Flash科目一写入
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Sub1_Write(void)
{
    if(flashStr.sub1_save)
    {
        if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_SUB1))                            // 判断是否有数据
        {     
            flash_erase_page(FLASH_SECTION_INDEX, FLASH_PAGE_SUB1);                      // 擦除原先数据
        } 
        flashStr.check++;
    
        flash_union_buffer[0].uint8_type = rtsStr.cone;
    
    
        flash_write_page_from_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_SUB1, 1);         //将缓冲区的数据写入flash中
        flash_buffer_clear();
        Buzzer_Enable(BuzzerOk);
        flashStr.sub1_save = false;
    }
}

/**
* @brief        Flash科目一读取
* @param
* @ref
* @author       NaiNong
* @note         
**/
void Flash_Sub1_Read(void)
{
    flash_buffer_clear();
    if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_SUB1))                            // 判断是否有数据
    {     
        flash_read_page_to_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_SUB1, 1);
        rtsStr.cone = flash_union_buffer[0].uint8_type;

    } 
}