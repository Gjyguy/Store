#include "Motor.h"

small_device_value_struct motor_value;      // 定义通讯参数结构体
MotorStruct motorStr;

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     无刷驱动 串口接收回调函数
// 参数说明     void
// 返回参数     void
// 使用示例     uart_control_callback(1000, -1000);
// 备注信息     用于解析接收到的速度数据  该函数需要在对应的串口接收中断中调用
//-------------------------------------------------------------------------------------------------------------------
void uart_control_callback(void)
{
    uint8 receive_data;                                                                     // 定义临时变量

    if(uart_query_byte(SMALL_DRIVER_UART, &receive_data))                                   // 接收串口数据
    {
        if(receive_data == 0xA5 && motor_value.receive_data_buffer[0] != 0xA5)              // 判断是否收到帧头 并且 当前接收内容中是否正确包含帧头
        {
            motor_value.receive_data_count = 0;                                             // 未收到帧头或者未正确包含帧头则重新接收
        }

        motor_value.receive_data_buffer[motor_value.receive_data_count ++] = receive_data;  // 保存串口数据

        if(motor_value.receive_data_count >= 7)                                             // 判断是否接收到指定数量的数据
        {
            if(motor_value.receive_data_buffer[0] == 0xA5)                                  // 判断帧头是否正确
            {

                motor_value.sum_check_data = 0;                                             // 清除校验位数据

                for(int i = 0; i < 6; i ++)
                {
                    motor_value.sum_check_data += motor_value.receive_data_buffer[i];       // 重新计算校验位
                }

                if(motor_value.sum_check_data == motor_value.receive_data_buffer[6])        // 校验数据准确性
                {

                    if(motor_value.receive_data_buffer[1] == 0x02)                          // 判断是否正确接收到 速度输出 功能字
                    {
                        motor_value.receive_left_speed_data  = (((int)motor_value.receive_data_buffer[2] << 8) | (int)motor_value.receive_data_buffer[3]);  // 拟合左侧电机转速数据

                        motor_value.receive_right_speed_data = (((int)motor_value.receive_data_buffer[4] << 8) | (int)motor_value.receive_data_buffer[5]);  // 拟合右侧电机转速数据

                        motorStr.Left_Encoder = motor_value.receive_right_speed_data;

                        motorStr.Right_Encoder = -motor_value.receive_left_speed_data;

                        motorStr.Average_Speed = (int16)((motorStr.Left_Encoder + motorStr.Right_Encoder) / 2);  // 计算平均转速
                    }

                    motor_value.receive_data_count = 0;                                     // 清除缓冲区计数值

                    memset(motor_value.receive_data_buffer, 0, 7);                          // 清除缓冲区数据
                }
                else
                {
                    motor_value.receive_data_count = 0;                                     // 清除缓冲区计数值

                    memset(motor_value.receive_data_buffer, 0, 7);                          // 清除缓冲区数据
                }
            }
            else
            {
                motor_value.receive_data_count = 0;                                         // 清除缓冲区计数值

                memset(motor_value.receive_data_buffer, 0, 7);                              // 清除缓冲区数据
            }
        }
    }
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     无刷驱动 设置电机占空比
// 参数说明     left_duty       左侧电机占空比  范围 -10000 ~ 10000  负数为反转
// 参数说明     right_duty      右侧电机占空比  范围 -10000 ~ 10000  负数为反转
// 返回参数     void
// 使用示例     small_driver_set_duty(1000, -1000);
// 备注信息
//-------------------------------------------------------------------------------------------------------------------
void small_driver_set_duty(int16 left_duty, int16 right_duty)
{
    motor_value.send_data_buffer[0] = 0xA5;                                         // 配置帧头

    motor_value.send_data_buffer[1] = 0X01;                                         // 配置功能字

    motor_value.send_data_buffer[2] = (uint8)((left_duty & 0xFF00) >> 8);           // 拆分 左侧占空比 的高八位

    motor_value.send_data_buffer[3] = (uint8)(left_duty & 0x00FF);                  // 拆分 左侧占空比 的低八位

    motor_value.send_data_buffer[4] = (uint8)((right_duty & 0xFF00) >> 8);          // 拆分 右侧占空比 的高八位

    motor_value.send_data_buffer[5] = (uint8)(right_duty & 0x00FF);                 // 拆分 右侧占空比 的低八位

    motor_value.send_data_buffer[6] = 0;                                            // 和校验清除

    for(int i = 0; i < 6; i ++)
    {
        motor_value.send_data_buffer[6] += motor_value.send_data_buffer[i];         // 计算校验位
    }

    uart_write_buffer(SMALL_DRIVER_UART, motor_value.send_data_buffer, 7);                     // 发送设置占空比的 字节包 数据
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     无刷驱动 获取速度信息
// 参数说明     void
// 返回参数     void
// 使用示例     small_driver_get_speed();
// 备注信息     仅需发送一次 驱动将周期发出速度信息(默认10ms)
//-------------------------------------------------------------------------------------------------------------------
void small_driver_get_speed(void)
{
    motor_value.send_data_buffer[0] = 0xA5;                                         // 配置帧头

    motor_value.send_data_buffer[1] = 0X02;                                         // 配置功能字

    motor_value.send_data_buffer[2] = 0x00;                                         // 数据位清空

    motor_value.send_data_buffer[3] = 0x00;                                         // 数据位清空

    motor_value.send_data_buffer[4] = 0x00;                                         // 数据位清空

    motor_value.send_data_buffer[5] = 0x00;                                         // 数据位清空

    motor_value.send_data_buffer[6] = 0xA7;                                         // 配置校验位

    uart_write_buffer(SMALL_DRIVER_UART, motor_value.send_data_buffer, 7);                     // 发送获取转速数据的 字节包 数据
}


//-------------------------------------------------------------------------------------------------------------------
// 函数简介     无刷驱动 参数初始化
// 参数说明     void
// 返回参数     void
// 使用示例     small_driver_init();
// 备注信息
//-------------------------------------------------------------------------------------------------------------------
void small_driver_init(void)
{
    memset(motor_value.send_data_buffer, 0, 7);                             // 清除缓冲区数据

    memset(motor_value.receive_data_buffer, 0, 7);                          // 清除缓冲区数据

    motor_value.receive_data_count          = 0;

    motor_value.sum_check_data              = 0;

    motor_value.receive_right_speed_data    = 0;

    motor_value.receive_left_speed_data     = 0;

    motorStr.CloseLoop = false;  
    motorStr.Integral = false;                            
    motorStr.Average_Speed = 0;                          
    motorStr.Left_Encoder = 0;
    motorStr.Right_Encoder = 0;
    motorStr.Left_Duty = 0;
    motorStr.Right_Duty = 0;
    motorStr.Distance = 0;
}


//-------------------------------------------------------------------------------------------------------------------
// 函数简介     无刷驱动 串口通讯初始化
// 参数说明     void
// 返回参数     void
// 使用示例     small_driver_uart_init();
// 备注信息
//-------------------------------------------------------------------------------------------------------------------
void small_driver_uart_init(void)
{
    uart_init(SMALL_DRIVER_UART, SMALL_DRIVER_BAUDRATE, SMALL_DRIVER_RX, SMALL_DRIVER_TX);      // 串口初始化

    uart_rx_interrupt(SMALL_DRIVER_UART, 1);                                                    // 使能串口接收中断

    small_driver_init();                                                                        // 结构体参数初始化

    small_driver_set_duty(0, 0);                                                                // 设置0占空比

    small_driver_get_speed();                                                                   // 获取实时速度数据
}

/**
* @brief        电机闭环速控
* @param        
* @ref
* @author       NaiNong
* @note
**/
void Motor_ControlLoop(void)
{
    motorStr.Left_Duty = (int16)(angle_v.out + spinStr.out + turn_v.out + bluetoothStr.turn);
    motorStr.Right_Duty = (int16)(angle_v.out - spinStr.out - turn_v.out - bluetoothStr.turn);

    if(motorStr.Left_Duty > MOTOR_PWM_MAX)
        motorStr.Left_Duty = MOTOR_PWM_MAX;
    else if(motorStr.Left_Duty < MOTOR_PWM_MIN)
        motorStr.Left_Duty = MOTOR_PWM_MIN;

    if(motorStr.Right_Duty > MOTOR_PWM_MAX)
        motorStr.Right_Duty = MOTOR_PWM_MAX;
    else if(motorStr.Right_Duty < MOTOR_PWM_MIN)
        motorStr.Right_Duty = MOTOR_PWM_MIN;
}

/**
* @brief        电机控制
* @param
* @ref
* @author       NaiNong
* @note
**/
void Motor_control(void)
{
    if(motorStr.CloseLoop)              //闭环控制
    {            
        Motor_ControlLoop();         
    }
    else
    {
        motorStr.Left_Duty = 0;    
        motorStr.Right_Duty = 0;    
    }

    small_driver_set_duty(-motorStr.Right_Duty, motorStr.Left_Duty);
}

/**
* @brief        电机失控保护
* @param
* @ref
* @author       NaiNong
* @note
**/
void Motor_protect(void)
{
    if((fabs(imu660rc_pitch) >80||fabs(imu660rc_roll) >70)&&motorStr.CloseLoop)              
    {
        Buzzer_Enable(BuzzerWarning);
        motorStr.CloseLoop = false;
    }
}

/**
* @brief        编码器积分距离
* @param
* @ref
* @author       NaiNong
* @note         在Pit_5ms()定时中断调用
**/
void Encoder_integral(void)
{
    if(motorStr.Integral)
    {
        motorStr.Distance += motorStr.Average_Speed;

        if(INS_rts_step == INS_RTS_SLALOM)
        {
            Ins_Save();
        }
        else if(rts_step == RTS_SLALOM)
        {
            Ins_Run();
        }
        else
        {
            if(motorStr.Distance >= MILEAGE)     
            {
                InsStr.Counter++;
                motorStr.Distance -= MILEAGE;    
            }
            else if(motorStr.Distance <= -MILEAGE) 
            {
                motorStr.Distance += MILEAGE;     
            }
        }

    }                          
    else
    {
        InsStr.Counter = 0;
        motorStr.Distance = 0;
    }
}

/**
* @brief       无刷驱动数据显示
* @param
* @ref
* @author       NaiNong
* @note
**/
void Motor_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[MOTOR DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "Left_Encoder:");
    ips200_show_int(8 * 22, 16 * 1,motorStr.Left_Encoder ,4); 

    ips200_show_string(8 * 0, 16 * 2, "Right_Encoder:");
    ips200_show_int(8 * 22, 16 * 2,motorStr.Right_Encoder ,4); 

    ips200_show_string(8 * 0, 16 * 3, "Average_Speed:");
    ips200_show_int(8 * 22, 16 * 3,motorStr.Average_Speed ,4);

    ips200_show_string(8 * 0, 16 * 4, "Left_Duty:");
    ips200_show_int(8 * 22, 16 * 4,motorStr.Left_Duty ,4); 

    ips200_show_string(8 * 0, 16 * 5, "Right_Duty:");
    ips200_show_int(8 * 22, 16 * 5,motorStr.Right_Duty ,4); 

    ips200_show_string(8 * 0, 16 * 6, "Distance:");
    ips200_show_int(8 * 22, 16 * 6,motorStr.Distance ,5); 

    ips200_show_string(8 * 0, 16 * 7, "Counter:");
    ips200_show_int(8 * 22, 16 * 7,InsStr.Counter ,5); 
}