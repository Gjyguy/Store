#ifndef PID_H
#define PID_H

#include "zf_common_headfile.h"

typedef struct {
    bool enable;           // Pid使能      

    float target;          // 目标值

    float Kp;              // 比例系数
    float Ki;              // 积分系数
    float Kd;              // 微分系数

    float err;             // 当前误差
    float err_prev;        // 上一时刻误差

    float out;             // PID 输出
    float out_max;         // 输出限幅
} PIDStruct;

typedef struct {
    float target;          // 目标速度

    //科目一速度参数
    float straight1;       // 直线1速度
    float straight2;       // 直线2速度
    float straight3;       // 直线3速度
    float slalom;          // 绕桩速度
    //科目二速度参数


    //科目三速度参数
    float bridge;          // 单边桥速度
    float shoulder;        // 路肩速度
} SpeedStruct;

extern PIDStruct angle_v;
extern PIDStruct angle;
extern PIDStruct speed;
extern PIDStruct turn_v;
extern PIDStruct turn;
extern PIDStruct bridge;

extern SpeedStruct speedctrl;

//外部函数声明
void PID_Init(PIDStruct *pidStruct, float Kp, float Ki, float Kd, float out_max, bool enable);
void PID_Position(PIDStruct *Pid, float Target, float Feedback);
void PID_Increment(PIDStruct *Pid, float Target, float Feedback);
void PID_AngleControl(PIDStruct *Pid, float Target, float Feedback);
void PID_Show(void);

void Speed_Init(void);
void Speed_Decision(void);
void Speed_Show(void);

#endif