#ifndef DISPLAY_H
#define DISPLAY_H

#include "zf_common_headfile.h"

/**
* @brief    显示状态枚举
**/
typedef enum {
    DISPLAY_MENU,                       // 菜单显示
    DISPLAY_INS,                        // 惯导状态显示
    DISPLAY_RTS,                        // 科目一显示
    DISPLAY_BATTERY,                    // 电池电压显示
    DISPLAY_SPEED,                      // 速度显示
    DISPLAY_IMU,                        // 陀螺仪数据显示
    DISPLAY_MOTOR,                      // 电机信息显示
    DISPLAY_PID,                        // PID参数显示
    DISPLAY_WMC,                        // 定点排雷显示
    DISPLAY_JUMP,                       // 跳跃状态显示
    DISPLAY_BRIDGE,                     // 单边桥状态显示
    DISPLAY_SHOULDER,                   // 路肩状态显示
}DisplayEnum;

/**
* @brief    IPS显示屏相关
**/
typedef struct {
    bool enable;
    bool Ins;                            //惯导显示
    bool Rts;                            //科目一显示
    bool Battery;                        //电池电压显示 
    bool Speed;                          //速度显示
    bool Imu;                            //陀螺仪数据显示
    bool Motor;                          //电机信息显示
    bool Pid;                            //PID参数显示
    bool Wmc;                            //定点排雷显示  
    bool Jump;                           //跳跃状态显示  
    bool Bridge;                         //单边桥状态显示
    bool Shoulder;                       //路肩状态显示
}DisplayStruct;

extern DisplayEnum displayState;         //当前显示状态
extern DisplayEnum lastDisplayState;     //上一次显示状态
extern DisplayStruct displaystr;         //显示状态结构体

//外部函数声明
void Display_Init(void);                //IPS显示屏初始化
void Display_Show(void);                //IPS显示屏显示

#endif