#include "Brc.h"

Jump_Step jump_step = JUMP_NONE;
JumpStruct jumpStr;

Bridge_Step bridge_step = BRIDGE_NONE;
BridgeStruct bridgeStr;

Shoulder_Step shoulder_step = SHOULDER_NONE;
ShoulderStruct shoulderStr;

/**
* @brief        Bumpy_Road_Course
* @param
* @ref          颠簸路段:交替单边桥、颠簸路段、草地路段等， 三级台阶和陡坡
* @author       NaiNong
* @note         
**/
void Brc_process(void)
{

}

/**
* @brief        跳跃参数初始化
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void Jump_Init(void)
{
    jumpStr.enable = false;
    jumpStr.angle = 100;

    jumpStr.count = 0;
    jumpStr.jump_count = 0;

    jumpStr.wait_time = 2000;
    jumpStr.jump_time = 110;
    jumpStr.fold_time = 150;
    jumpStr.extend_time = 170;
    jumpStr.cushion_time = 60;
    jumpStr.exit_time = 400;
}

/**
* @brief        跳跃线程控制器
* @param
* @ref          在Pit_1ms()定时中断函数调用
* @author       NaiNong
* @note
**/
void Jump_Timer(void)
{
    if(jumpStr.enable)
        jumpStr.jump_count++;
    else
        jumpStr.jump_count = 0;
}

/**
* @brief        跳跃控制函数
* @param
* @ref          在Pit_1ms()定时中断函数调用
* @author       NaiNong
* @note
**/
void Jump_control(void)
{
    switch (jump_step) 
    {
        case JUMP_NONE:
        {
            if (jumpStr.enable)
            {    
                Buzzer_Enable(BuzzerSysStart);                      
                jumpStr.jump_count = 0;
                jump_step = JUMP_WAIT;
            }
                
            break;
        }

        case JUMP_WAIT:
        {
            if(jumpStr.jump_count >= jumpStr.wait_time)
            {          
                jumpStr.jump_count = 0;
                jump_step = JUMP_PUSH;       
            }
        
            break;
        }

        case JUMP_PUSH:
        {
            Servo_Angle(160);
            if(jumpStr.jump_count >= jumpStr.jump_time)
            {    
                jumpStr.jump_count = 0;
                jump_step = JUMP_FOLD;                
            }
            
            break;
        }
        
        case JUMP_FOLD:
        {
            Servo_Angle(50);
            if(jumpStr.jump_count >= jumpStr.fold_time)
            {
                jumpStr.jump_count = 0;
                jump_step = JUMP_EXTEND;
            }
            
            break;
        }
        
        case JUMP_EXTEND:
        {
            Servo_Angle(100);
            if(jumpStr.jump_count >= jumpStr.extend_time)
            {
                jumpStr.jump_count = 0;
                jump_step = JUMP_CUSHION;
            }
            
            break;
        }
        
        case JUMP_CUSHION:
        {
            jumpStr.angle -= 0.5;
            Servo_Angle(jumpStr.angle);
            
            if(jumpStr.jump_count >= jumpStr.cushion_time)
            {   
                jumpStr.jump_count = 0;
                jumpStr.angle = 100;
                jump_step = JUMP_EXIT;
            }
 
            break;
        }
        
        case JUMP_EXIT:
        {
            if(jumpStr.jump_count >= jumpStr.exit_time)
            {
                Buzzer_Enable(BuzzerDing);      
                jumpStr.jump_count = 0;  
                jumpStr.enable = false;
                jump_step = JUMP_NONE;
            }

            break;
        }

    }
}

/**
* @brief        跳跃参数显示
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void Jump_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[JUMP DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "enable:");
    ips200_show_int(8 * 15, 16 * 1,jumpStr.enable ,1); 
    
    ips200_show_string(8 * 0, 16 * 2, "step:");
    ips200_show_int(8 * 15, 16 * 2,jump_step ,1); 
    
    ips200_show_string(8 * 0, 16 * 3, "count:");
    ips200_show_int(8 * 15, 16 * 3,jumpStr.jump_count ,4); 

    ips200_show_string(8 * 0, 16 * 4, "angle:");
    ips200_show_float(8 * 15, 16 * 4,jumpStr.angle, 3, 2); 

}

/**
* @brief        单边桥控制函数
* @param
* @ref          在Pit_10ms()定时中断函数调用
* @author       NaiNong
* @note
**/
void Bridge_control(void)
{
    switch (bridge_step) 
    {
        case BRIDGE_NONE:
        {
            if (bridgeStr.enable)
            {    
                //Buzzer_Enable(BuzzerSysStart);
                bridgeStr.angle = imu660rc_yaw;                      
                bridge_step = BRIDGE_ENTER;
            }
                
            break;
        }

        case BRIDGE_ENTER:
        {
            bridgeStr.height = 50;

            PID_Position(&turn, bridgeStr.angle, imu660rc_yaw);
            PID_Increment(&bridge, 0, imu660rc_roll);

            if(bridge.out >= 0){
                bridgeStr.height_left = -bridge.out;
                bridgeStr.height_right = bridge.out;
            }
            else{
                bridgeStr.height_left = -bridge.out;
                bridgeStr.height_right = bridge.out;
            }

            if (0)
                bridge_step = BRIDGE_EXIT;

                
            break;
        }

        case BRIDGE_EXIT:
        {
            bridgeStr.angle = 0;
            bridgeStr.height = 0;
            bridgeStr.height_left = 0;
            bridgeStr.height_right = 0;
            bridge_step = BRIDGE_NONE; 
            break;
        }
    }
}

/**
* @brief        单边桥参数显示
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void Bridge_Show(void)
{
    ips200_show_string(8 * 6, 16 * 0, "[BRIDGE DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "enable:");
    ips200_show_int(8 * 15, 16 * 1,bridgeStr.enable ,1); 
    
    ips200_show_string(8 * 0, 16 * 2, "step:");
    ips200_show_int(8 * 15, 16 * 2,bridge_step ,1);

    ips200_show_string(8 * 0, 16 * 3, "angle:");
    ips200_show_float(8 * 15, 16 * 3,bridgeStr.angle, 3, 2); 

    ips200_show_string(8 * 0, 16 * 4, "yaw:");
    ips200_show_float(8 * 15, 16 * 4,imu660rc_yaw, 3, 2); 

    ips200_show_string(8 * 0, 16 * 5, "roll:");
    ips200_show_float(8 * 15, 16 * 5,imu660rc_roll, 3, 2); 

    ips200_show_string(8 * 0, 16 * 6, "height:");
    ips200_show_float(8 * 15, 16 * 6, bridgeStr.height, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 7, "heigh_l:");
    ips200_show_float(8 * 15, 16 * 7, bridgeStr.height_left, 3, 2); 

    ips200_show_string(8 * 0, 16 * 8, "height_r:");
    ips200_show_float(8 * 15, 16 * 8, bridgeStr.height_right, 3, 2); 
}

/**
* @brief        路肩控制函数
* @param
* @ref          在Brc_process()函数调用
* @author       NaiNong
* @note
**/
void Shoulder_control(void)
{
    switch (shoulder_step) 
    {
        case SHOULDER_NONE:
        {
            if (shoulderStr.enable)
            {    
                Buzzer_Enable(BuzzerSysStart);
                shoulderStr.angle = imu660rc_yaw;  
                shoulderStr.height = 30;                    
                shoulder_step = SHOULDER_ENTER;
            }
                
            break;
        }

        case SHOULDER_ENTER:
        {
            PID_Position(&turn, shoulderStr.angle, imu660rc_yaw);

            if (0)
                shoulder_step = SHOULDER_EXIT;

                
            break;
        }

        case SHOULDER_EXIT:
        {
            shoulderStr.height = 0;
            shoulderStr.angle = 0;
            shoulder_step = SHOULDER_NONE; 
            break;
        }
    }
}

/**
* @brief        路肩参数显示
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void Shoulder_Show(void)
{
    ips200_show_string(8 * 4, 16 * 0, "[SHOULDER DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "enable:");
    ips200_show_int(8 * 15, 16 * 1,shoulderStr.enable ,1); 
    
    ips200_show_string(8 * 0, 16 * 2, "step:");
    ips200_show_int(8 * 15, 16 * 2,shoulder_step ,1);

    ips200_show_string(8 * 0, 16 * 3, "angle:");
    ips200_show_float(8 * 15, 16 * 3,shoulderStr.angle, 3, 2); 

    ips200_show_string(8 * 0, 16 * 4, "yaw:");
    ips200_show_float(8 * 15, 16 * 4,imu660rc_yaw, 3, 2); 

    ips200_show_string(8 * 0, 16 * 5, "height:");
    ips200_show_float(8 * 15, 16 * 5, shoulderStr.height, 3, 2); 
    
}