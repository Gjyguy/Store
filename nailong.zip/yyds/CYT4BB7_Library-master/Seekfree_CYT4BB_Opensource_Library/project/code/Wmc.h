#ifndef WPM_H
#define WPM_H

#include "zf_common_headfile.h"

typedef enum {
    WMC_NONE = 0,           // 空闲
    WMC_SEEK,               // 寻找并进入雷区
    WMC_INSIDE,             // 已在雷区内，开始旋转
    WMC_EXIT,               // 旋转完成，离开雷区
    WMC_FINISH              // 科目完成
}Wmc_Step;

/**
 * @brief 旋转状态
 */
typedef enum {
    none = 0,       
    spin,      
    finish,
}Spin_Step;

/**
* @brief    科目二相关
**/
typedef struct {
    bool enable;
}WmcStruct;

/**
* @brief    旋转相关
**/
typedef struct {
    bool left;
    int16 out;
    float last_yaw;
    float total_yaw;
    float delta;
    float error;
}SpinStruct;

extern Spin_Step spin_step;
extern WmcStruct wmcStr;
extern SpinStruct spinStr;

extern bool spin_enable;

void Wmc_process(void);
void Spin_process(void);
void Wmc_Show(void);

#endif