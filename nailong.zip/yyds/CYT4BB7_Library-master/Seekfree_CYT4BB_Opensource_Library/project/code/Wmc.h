#ifndef WPM_H
#define WPM_H

#include "zf_common_headfile.h"

/**
 * @brief 旋转状态
 */
typedef enum {
    none = 0,       
    spin,      
    finish,
}Spin_Step;

/**
* @brief    旋转相关
**/
typedef struct {
    bool left;
    int16 out;
    float last_yaw;
    float total_yaw;
    float delta;
    float error;
}SpinStruct;

extern Spin_Step spin_step;
extern SpinStruct spinStr;

extern bool spin_enable;

void Wmc_process(void);
void Spin_process(void);
void Wmc_Show(void);

#endif