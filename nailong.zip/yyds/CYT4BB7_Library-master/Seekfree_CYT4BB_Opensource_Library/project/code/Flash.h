#ifndef FLASH_H
#define FLASH_H

#include "zf_common_headfile.h"

#define FLASH_SECTION_INDEX        (0)                // 存储数据用的扇区
#define FLASH_PAGE_PARAM           (0)                // 存储数据用的页码
#define FLASH_PAGE_SUB1            (1)                // 存储科目一的页码
#define FLASH_PAGE_SUB2            (2)                // 存储科目二的页码
#define FLASH_PAGE_SUB3            (3)                // 存储科目三的页码
#define FLASH_PAGE_GPS             (4)                // 存储点位用的页码
#define FLASH_PAGE_INS             (5)                // 存储惯导用的页码
#define FLASH_PAGE_MAX             (95)               // 存储惯导用的页码

typedef struct{
    bool sub1_save;
    uint8 check;
}FlashStruct;

extern FlashStruct flashStr;

void Flash_Init(void);
void Flash_Read(uint8 page_index, uint16 len);
void Flash_Write(uint8 page_index, uint16 len);
void Flash_Param_Read(void);
void Flash_Param_Write(void);
void Flash_Sub1_Write(void);
void Flash_Sub1_Read(void);
#endif