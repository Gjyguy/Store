#ifndef FLASH_H
#define FLASH_H

#include "zf_common_headfile.h"

#define FLASH_SECTION_INDEX        (0)                // 存储数据用的扇区
#define FLASH_PAGE_PARAM           (0)                // 存储数据用的页码
#define FLASH_PAGE_GPS             (1)                // 存储点位用的页码
#define FLASH_PAGE_INS             (2)                // 存储惯导用的页码
#define FLASH_PAGE_MAX             (95)                // 存储惯导用的页码

typedef struct{
    bool enable;
    uint8 check;
}FlashStruct;

extern FlashStruct flashStr;

void Flash_Init(void);
void Flash_Read(uint8 page_index, uint16 len);
void Flash_Write(uint8 page_index, uint16 len);
void Flash_Param_Read(void);
void Flash_Param_Write(void);

#endif