#ifndef MENU_H
#define MENU_H

#include "zf_common_headfile.h"

#define MENU_MAX_SIZE       (256)   //菜单最大节点数量
#define SETUP_LEN           (7)     //菜单步进值数量

/**
* @brief    菜单节点类型枚举
**/
typedef enum {
    Menu_Folder = 0,
    int32_box,
    uint32_box,
    int16_box,
    uint16_box,
    int8_box,
    uint8_box,
    float_box,
    int_box,
    bool_box,
}MENU_KIND;

/**
* @brief    菜单节点结构体
**/
typedef struct Menu_Item {
    const char* name;                   //记录节点名称
    void* data;                         //指向存放变量的数据
    MENU_KIND kind;                     //记录节点属性
    uint8_t sons;                       //记录子节点数量
    uint8_t No;                         //记录当前是父节点第几个成员
    bool select;                        //记录当前节点是否被选中
    struct Menu_Item *father;           //指向父节点
    struct Menu_Item *first_son;        //指向第一个子节点
    struct Menu_Item *next_brother;     //指向下一个兄弟节点
    struct Menu_Item *last_brother;     //指向上一个兄弟节点
}Menu_Item;

extern double SetupNumber[SETUP_LEN];   //菜单步进值数组
extern uint8 SetupIndex;                //菜单步进值索引
extern Menu_Item head;                  //菜单头节点
extern Menu_Item *key;                  //当前选中节点

extern uint16 test;

//内部函数声明
void Create_Menu_Item(Menu_Item *father, Menu_Item *me, const char name[],void *data, MENU_KIND kind);      //创建菜单项
void Create_Menu_Folder(Menu_Item* father, Menu_Item* me, const char name[]);                               //创建文件夹
void Create_Menu_Number(Menu_Item* father, Menu_Item* me, const char name[],void *data, MENU_KIND kind);    //创建文件
Menu_Item* dynamicCreate_Menu_Folder(Menu_Item* father, const char name[]);                                 //动态创建文件夹
void dynamicCreate_Menu_Number(Menu_Item* father, const char name[], void* data, MENU_KIND kind);           //动态创建文件

void show_key(void);                    //菜单光标显示
void show_name(void);                   //菜单名称显示
void show_Setup(void);                  //菜单步进值显示
void show_number(void);                 //菜单数值显示

//外部函数声明
void Menu_Init(void);                   //菜单初始化
void Menu_Show(void);                   //菜单显示

#endif