#ifndef MOTOR_H
#define MOTOR_H

#include "zf_common_headfile.h"

#define SMALL_DRIVER_UART                       (UART_4        )

#define SMALL_DRIVER_BAUDRATE                   (460800        )

#define SMALL_DRIVER_RX                         (UART4_TX_P14_1)

#define SMALL_DRIVER_TX                         (UART4_RX_P14_0)

#define  MOTOR_PWM_MAX                          (4000)        
#define  MOTOR_PWM_MIN                          (-4000)       
#define  MOTOR_SPEED_MAX                        (400)

/**
* @brief    电机相关
**/
typedef struct
{
    bool CloseLoop; 
    bool Integral;                            
    int16 Average_Speed;                          
    int16 Left_Encoder;
    int16 Right_Encoder;
    int16 Left_Duty;
    int16 Right_Duty;
    int16 Distance;
}MotorStruct;

typedef struct
{
    uint8 send_data_buffer[7];                  // 发送缓冲数组

    uint8 receive_data_buffer[7];               // 接收缓冲数组

    uint8 receive_data_count;                   // 接收计数

    uint8 sum_check_data;                       // 校验位

    int16 receive_left_speed_data;              // 接收到的左侧电机速度数据

    int16 receive_right_speed_data;             // 接收到的右侧电机速度数据

}small_device_value_struct;

extern small_device_value_struct motor_value;

extern MotorStruct motorStr;

//内部函数声明
void uart_control_callback(void);                                   // 无刷驱动 串口接收回调函数

void small_driver_set_duty(int16 left_duty, int16 right_duty);      // 无刷驱动 设置电机占空比

void small_driver_get_speed(void);                                  // 无刷驱动 获取速度信息

void small_driver_uart_init(void);                                  // 无刷驱动 串口通讯初始化

//外部函数声明
void Motor_ControlLoop(void);                                       // 无刷驱动 闭环速控
void Motor_control(void);                                           // 无刷驱动 电机控制
void Motor_protect(void);                                           // 无刷驱动 失控保护
void Encoder_integral(void);                                        // 无刷驱动 积分距离
void Motor_Show(void);                                              // 无刷驱动 数据显示
#endif
