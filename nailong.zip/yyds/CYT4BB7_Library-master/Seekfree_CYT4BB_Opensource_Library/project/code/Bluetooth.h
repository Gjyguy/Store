#ifndef BLUETOOTH_H
#define BLUETOOTH_H

#include "zf_common_headfile.h"

#define BT_DATA_LEN     (7)         //蓝牙数据长度

/**
* @brief    蓝牙解析状态机
**/
typedef enum {
    BT_WAIT_HEAD,
    BT_GET_DATA,
    BT_GET_CHECKSUM,
    BT_WAIT_TAIL
}Bluetooth_state;

/**
* @brief    蓝牙相关
**/
typedef struct {
    bool enable;                        // 使能标志
    bool connect;                       // 连接状态
    uint8 status;                       // 当前蓝牙状态
    uint8 last_status;                  // 上一次蓝牙状态
    float speed;                        // 接收的速度值
    int16_t turn;                       // 接收的转向值
}BluetoothStruct;

extern BluetoothStruct bluetoothStr;          //蓝牙结构体
extern fifo_struct bluetooth_fifo;

//外部函数声明
void Bluetooth_Init(void);                              // 蓝牙初始化
void Bluetooth_Check(void);
void Bluetooth_IRQHandler(void); 

#endif