#include "Bluetooth.h"


static uint8_t rx_data_buffer[BT_DATA_LEN];
static uint8_t data_index = 0;
static uint8_t rx_check = 0;            // 接收到的校验和
static uint8_t calc_check = 0;          // 计算出的校验和

Bluetooth_state bt_state = BT_WAIT_HEAD;
BluetoothStruct bluetoothStr;
fifo_struct bluetooth_fifo;

uint8_t bluetooth_rx_buffer[256];
uint8_t uart_get_data;
uint8_t fifo_get_data;
uint8_t fifo_data_count;

void Bluetooth_Init(void)
{
    uart_init(UART_1, 9600, UART1_TX_P04_1, UART1_RX_P04_0);
    uart_rx_interrupt(UART_1, 1);
    fifo_init(&bluetooth_fifo, FIFO_DATA_8BIT, bluetooth_rx_buffer, sizeof(bluetooth_rx_buffer));
    gpio_init(P22_6, GPI, 0, GPI_PULL_DOWN);

    bluetoothStr.enable = false;
    bluetoothStr.connect = false;
    bluetoothStr.last_status = gpio_get_level(P22_6);
}

void Bluetooth_Check(void)
{
    bluetoothStr.status = gpio_get_level(P22_6);

    if(bluetoothStr.last_status != bluetoothStr.status){
        Buzzer_Enable(BuzzerOk);  
    }

    if(bluetoothStr.status){
        bluetoothStr.connect = true;
    }
    else{
        bluetoothStr.connect = false;
    }

    bluetoothStr.last_status = bluetoothStr.status;
}

void Bluetooth_IRQHandler(void)
{
    if (uart_query_byte(UART_1, &uart_get_data)) {
        fifo_write_element(&bluetooth_fifo, uart_get_data);
    }

    fifo_data_count = fifo_used(&bluetooth_fifo);
    if (fifo_data_count > 0) 
    {
        fifo_read_element(&bluetooth_fifo, &fifo_get_data, FIFO_READ_AND_CLEAN);
 
        switch (bt_state) 
        {
            case BT_WAIT_HEAD:
                if (fifo_get_data == 0xA5) {
                    bt_state = BT_GET_DATA;
                    calc_check = 0;
                    data_index = 0;
                }
                break;

            case BT_GET_DATA:
                rx_data_buffer[data_index++] = fifo_get_data;
                calc_check += fifo_get_data;
                if (data_index >= BT_DATA_LEN) {
                    bt_state = BT_GET_CHECKSUM;
                }
                break;

            case BT_GET_CHECKSUM:
                rx_check = fifo_get_data;
                bt_state = BT_WAIT_TAIL;
                break;

            case BT_WAIT_TAIL:
                if (fifo_get_data == 0x5A) 
                {
                    if ((calc_check & 0xFF) == rx_check) {
                        // 解析数据字节中的两个 bool 位（bit0 = 第一位，bit1 = 第二位）

                        //解析第一个字节bool类型，8位
                        motorStr.CloseLoop = (rx_data_buffer[0] >> 0) & 0x01;
                        INS_rtsStr.enable = (rx_data_buffer[0] >> 1) & 0x01;


                        //解析short类型，2字节
                        bluetoothStr.turn = (int16_t)((uint16_t)rx_data_buffer[2] << 8 | rx_data_buffer[1]);

                        //解析float类型，4字节
                        uint8_t *float_ptr = (uint8_t *)&bluetoothStr.speed;
                        for (int i = 0; i < 4; i++) {
                            float_ptr[i] = rx_data_buffer[3 + i];   // 索引1~4
                        }

                    }
                }
                bt_state = BT_WAIT_HEAD;
                break;

            default:
                bt_state = BT_WAIT_HEAD;
                break;
        }
    }
}