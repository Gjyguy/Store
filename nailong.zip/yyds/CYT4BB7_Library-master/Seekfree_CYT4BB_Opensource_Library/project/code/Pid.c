#include "Pid.h"

PIDStruct angle_v;
PIDStruct angle;
PIDStruct speed;
PIDStruct turn_v;
PIDStruct turn;
PIDStruct bridge;

SpeedStruct speedctrl;

/**
* @brief        PID参数初始化
* @param
* @ref
* @author       NaiNong
* @note
**/
void PID_Init(PIDStruct *pidStruct, float Kp, float Ki, float Kd, float out_max, bool enable)
{
    //初始化PID参数
    pidStruct->enable = enable;

    pidStruct->Kp = Kp;
    pidStruct->Ki = Ki;
    pidStruct->Kd = Kd;

    pidStruct->out_max = out_max;

    pidStruct->target = 0;
    pidStruct->err = 0;
    pidStruct->err_prev = 0;
    pidStruct->out = 0;
}

/**
* @brief        位置式 PID
* @param        
* @ref          只需要PD
* @author       NaiNong
* @note
**/
void PID_Position(PIDStruct *Pid, float Target, float Feedback)
{
    if(Pid->enable)
    {
        //更新误差
        Pid->err = Target - Feedback;   //计算误差
        Pid->out = Pid->Kp * Pid->err + Pid->Kd * (Pid->err - Pid->err_prev);
        Pid->err_prev = Pid->err;

        if(Pid->out > Pid->out_max)
            Pid->out = Pid->out_max;
        else if (Pid->out < -Pid->out_max)
            Pid->out = -Pid->out_max;
    }
    else
    {
        Pid->target = 0;
        Pid->err_prev = 0;
        Pid->err = 0;
        Pid->out = 0;
    }
}

/**
* @brief        增量式 PID
* @param
* @ref          只需要PI
* @author       NaiNong
* @note
**/
void PID_Increment(PIDStruct *Pid, float Target, float Feedback)
{
    if(Pid->enable)
    {
        //更新误差
        Pid->err = Target - Feedback;   //计算误差
        Pid->out += Pid->Kp * (Pid->err - Pid->err_prev) + Pid->Ki * Pid->err;
        Pid->err_prev = Pid->err;

        if(Pid->out > Pid->out_max)
            Pid->out = Pid->out_max;
        else if (Pid->out < -Pid->out_max)
            Pid->out = -Pid->out_max;
    }
    else
    {
        Pid->err_prev = 0;
        Pid->err = 0;
        Pid->out = 0;
    }
}

/**
* @brief        位置式 PID归一化到 [-180, 180]
* @param        
* @ref          只需要PD
* @author       NaiNong
* @note
**/
void PID_AngleControl(PIDStruct *Pid, float Target, float Feedback)
{
    if(Pid->enable)
    {
        //更新误差
        Pid->err = Target - Feedback;   //计算误差

        if (Pid->err > 180.0f) Pid->err -= 360.0f;
        else if (Pid->err < -180.0f) Pid->err += 360.0f;

        Pid->out += Pid->Kp * (Pid->err - Pid->err_prev) + Pid->Ki * Pid->err;
        Pid->err_prev = Pid->err;
        
        if(Pid->out > Pid->out_max)
            Pid->out = Pid->out_max;
        else if (Pid->out < -Pid->out_max)
            Pid->out = -Pid->out_max;
    }
    else
    {
        Pid->err_prev = 0;
        Pid->err = 0;
        Pid->out = 0;
    }
}

/**
* @brief        PID数据显示
* @param
* @ref          
* @author       NaiNong
* @note         
**/
void PID_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[PID DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "kp");
    ips200_show_string(8 * 8, 16 * 1, "ki");
    ips200_show_string(8 * 16, 16 * 1, "kd");
    ips200_show_string(8 * 22, 16 * 1, "out");

    //角速度环参数
    ips200_show_float(8 * 0, 16 * 2,angle_v.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 2,angle_v.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 2,angle_v.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 2,angle_v.out, 4, 1); 

    //角度环参数
    ips200_show_float(8 * 0, 16 * 3,angle.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 3,angle.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 3,angle.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 3,angle.out, 4, 1); 

    //速度环参数
    ips200_show_float(8 * 0, 16 * 4,speed.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 4,speed.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 4,speed.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 4,speed.out, 4, 1); 

    //转向角速度环参数
    ips200_show_float(8 * 0, 16 * 5,turn_v.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 5,turn_v.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 5,turn_v.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 5,turn_v.out, 4, 1);

    //转向角度环参数
    ips200_show_float(8 * 0, 16 * 6,turn.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 6,turn.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 6,turn.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 6,turn.out, 4, 1); 

    //单边桥参数
    ips200_show_float(8 * 0, 16 * 7,bridge.Kp, 3, 2); 
    ips200_show_float(8 * 8, 16 * 7,bridge.Ki, 3, 2); 
    ips200_show_float(8 * 16, 16 * 7,bridge.Kd, 3, 2); 
    ips200_show_float(8 * 22, 16 * 7,bridge.out, 4, 1); 

    //使能参数
    ips200_show_string(8 * 0, 16 * 10, "angle_v");
    ips200_show_int(8 * 0, 16 * 11,angle_v.enable ,1); 

    ips200_show_string(8 * 10, 16 * 10, "angle");
    ips200_show_int(8 * 10, 16 * 11,angle.enable ,1); 

    ips200_show_string(8 * 20, 16 * 10, "speed");
    ips200_show_int(8 * 20, 16 * 11,speed.enable ,1); 

    ips200_show_string(8 * 0, 16 * 12, "turn_v");
    ips200_show_int(8 * 0, 16 * 13,turn_v.enable ,1); 

    ips200_show_string(8 * 10, 16 * 12, "turn");
    ips200_show_int(8 * 10, 16 * 13,turn.enable ,1); 

    ips200_show_string(8 * 20, 16 * 12, "bridge");
    ips200_show_int(8 * 20, 16 * 13,bridge.enable ,1); 

}

/**
* @brief        Speed参数初始化
* @param
* @ref
* @author       NaiNong
* @note
**/
void Speed_Init(void)
{
    //初始化速度参数
    speedctrl.target = 0;

    //科目一速度参数
    speedctrl.straight1 = 600;
    speedctrl.straight2 = 350;
    speedctrl.straight3 = 450;
    speedctrl.slalom = 300;
    //科目二速度参数


    //科目三速度参数
    speedctrl.bridge = 110;
    speedctrl.shoulder = 180;
}

/**
* @brief        速度决策
* @param
* @ref
* @author       NaiNong
* @note
**/
void Speed_Decision(void)
{
    if(bluetoothStr.connect)
    {
        speedctrl.target = bluetoothStr.speed;
    }
/*
    if(bridgeStr.enable)
        speedctrl.target = speedctrl.bridge;
    else if(shoulderStr.enable)
        speedctrl.target = speedctrl.shoulder;
    else
        speedctrl.target = 0;
*/
}

void Speed_Show(void)
{
    ips200_show_string(8 * 6, 16 * 0, "[SPEED DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "target:");
    ips200_show_float(8 * 15, 16 * 1,speedctrl.target, 3, 1); 

    ips200_show_string(8 * 6, 16 * 2, "[TASK1 DISPLAY]");

    ips200_show_string(8 * 0, 16 * 3, "straight1:");
    ips200_show_float(8 * 15, 16 * 3,speedctrl.straight1, 3, 1); 

    ips200_show_string(8 * 0, 16 * 4, "straight2:");
    ips200_show_float(8 * 15, 16 * 4,speedctrl.straight2, 3, 1); 

    ips200_show_string(8 * 0, 16 * 5, "straight3:");
    ips200_show_float(8 * 15, 16 * 5,speedctrl.straight3, 3, 1); 

    ips200_show_string(8 * 0, 16 * 6, "slalom:");
    ips200_show_float(8 * 15, 16 * 6,speedctrl.slalom, 3, 1); 

    ips200_show_string(8 * 6, 16 * 7, "[TASK2 DISPLAY]");

    ips200_show_string(8 * 6, 16 * 8, "[TASK3 DISPLAY]");

    ips200_show_string(8 * 0, 16 * 9, "bridge:");
    ips200_show_float(8 * 15, 16 * 9,speedctrl.bridge, 3, 1); 

    ips200_show_string(8 * 0, 16 * 10, "shoulder:");
    ips200_show_float(8 * 15, 16 * 10,speedctrl.shoulder, 3, 1); 
}

