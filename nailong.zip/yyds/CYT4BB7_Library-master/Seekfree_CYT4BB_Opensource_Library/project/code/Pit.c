#include "Pit.h"

PitStruct pitStr;

/**
* @brief       定时中断初始化
* @param
* @ref
* @author       NaiNong
* @note
**/
void Pit_Init(void)
{
    pit_ms_init(PIT_CH0, 1);

    pitStr.Counter_1ms = 0;
    pitStr.Counter_5ms = 0;
    pitStr.Counter_10ms = 0;
}

/**
* @brief       1ms定时中断处理函数
* @param
* @ref
* @author       NaiNong
* @note
**/
void Pit_1ms(void)
{
    pitStr.Counter_1ms++;
    if(pitStr.Counter_1ms == 1)
    {
        pitStr.Counter_1ms = 0;

        Jump_Timer();
        Buzzer_Timer();

        PID_Position(&angle_v, angle.out, -imu660rc_gyro_y);
        PID_Position(&turn_v, turn.out, imu660rc_gyro_z);
 
        if(servoStr.enable)
            Servo_control(-speed.out, -speed.out, bridgeStr.height+bridgeStr.height_left+shoulderStr.height, bridgeStr.height+bridgeStr.height_right+shoulderStr.height);
        else
            Servo_control(0,0,0,0);
            
        Motor_control(); 
        Jump_control();
    }
}

/**
* @brief       5ms定时中断处理函数
* @param
* @ref
* @author       NaiNong
* @note
**/
void Pit_5ms(void)
{
    pitStr.Counter_5ms++;
    if(pitStr.Counter_5ms == 5)
    {
        pitStr.Counter_5ms = 0;
        Encoder_integral();
        PID_Position(&angle, 0, imu660rc_pitch);
        PID_AngleControl(&turn, turn.target, imu660rc_yaw);

    }
}

/**
* @brief       10ms定时中断处理函数
* @param
* @ref
* @author       NaiNong
* @note
**/
void Pit_10ms(void)
{
    pitStr.Counter_10ms++;
    if(pitStr.Counter_10ms == 10)
    {
        pitStr.Counter_10ms = 0;

        PID_Position(&speed, speedctrl.target, (float)motorStr.Average_Speed);
        //Bridge_control();
        //Shoulder_control();
        
    }
}