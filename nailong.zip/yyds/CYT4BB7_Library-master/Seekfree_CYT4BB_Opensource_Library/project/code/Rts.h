#ifndef RTS_H
#define RTS_H

#include "zf_common_headfile.h"

/**
 * @brief 科目一场景状态
 */
typedef enum {
    RTS_NONE = 0,               // 无
    RTS_STRAIGHT_1,             // 前进直线（第一段）
    RTS_TURN,                   // 掉头
    RTS_STRAIGHT_2,             // 掉头直线（第二段）
    RTS_SLALOM,                 // 绕桩
    RTS_STRAIGHT_3,             // 冲刺直线（第三段）
    RTS_FINISH,                 // 结束    
}Rts_Step;

/**
* @brief    科目一相关
**/
typedef struct {
    bool enable;                //科目一使能
    uint16 Counter;             //计数器
    uint16 time;                
}RtsStruct;

extern Rts_Step rts_step;
extern RtsStruct rtsStr;

void Rts_Init(void);
void Rts_process(void);
void Rts_Show(void);

#endif