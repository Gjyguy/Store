#ifndef IMU_H
#define IMU_H

#include "zf_common_headfile.h"

//外部函数声明
void Imu_Init(void);        //陀螺仪初始化
void Imu_Handle(void);      //陀螺仪数据处理
void Imu_Show(void);        //陀螺仪数据显示

#endif