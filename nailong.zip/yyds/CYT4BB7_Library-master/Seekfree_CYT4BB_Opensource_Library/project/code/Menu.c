#include "Menu.h"

static Menu_Item menu_item_arr[MENU_MAX_SIZE];
static uint8 menu_arr_index = 0;

double SetupNumber[SETUP_LEN] = {0.001, 0.01, 0.1, 1, 10, 100, 1000};
uint8 SetupIndex = 3;

Menu_Item head;
Menu_Item *key;

uint16 test = 0;

/**
* @brief        创建菜单项
* @param       
* @ref
* @author       NaiNong
* @note
**/
void Create_Menu_Item(Menu_Item *father, Menu_Item *me, const char name[],void *data, MENU_KIND kind)
{
    if (father->kind != Menu_Folder) return;
   
    me->name = name;
    me->sons = 0;
    me->select = false;

    me->father = father;
    me->first_son = NULL;
    me->next_brother = NULL;
    me->last_brother = NULL;

    me->data = data;
    me->kind = kind;
    
    if (father->sons == 0)
    {
        father->first_son = me;
    }
    else
    {
        Menu_Item *p = father->first_son;
        while (p->next_brother != NULL)
            p = p->next_brother;

        p->next_brother = me;
        me->last_brother = p;
    }
    me->No = father->sons;
    father->sons++;
}

/**
* @brief        创建文件夹
* @param       
* @ref
* @author       NaiNong
* @note
**/
void Create_Menu_Folder(Menu_Item* father, Menu_Item* me, const char name[])
{
    Create_Menu_Item(father, me, name,NULL, Menu_Folder);
}

/**
* @brief        创建文件
* @param       
* @ref
* @author       NaiNong
* @note
**/
void Create_Menu_Number(Menu_Item* father, Menu_Item* me, const char name[],void *data, MENU_KIND kind)
{
    Create_Menu_Item(father, me, name, data, kind);
}

/**
* @brief        动态创建文件夹
* @param       
* @ref
* @author       NaiNong
* @note
**/
Menu_Item* dynamicCreate_Menu_Folder(Menu_Item* father, const char name[])
{
    Menu_Item *me= &menu_item_arr[menu_arr_index++];

    Create_Menu_Item(father, me, name, NULL, Menu_Folder);

    return me;
}

/**
* @brief        动态创建文件
* @param       
* @ref
* @author       NaiNong
* @note
**/
void dynamicCreate_Menu_Number(Menu_Item* father, const char name[], void* data, MENU_KIND kind)
{
    Menu_Item* me = &menu_item_arr[menu_arr_index++];

    Create_Menu_Item(father, me, name, data, kind);
}

/**
* @brief        菜单初始化
* @param       
* @ref
* @author       NaiNong
* @note
**/
void Menu_Init(void)
{
    head.data = NULL;
    head.father = NULL;
    head.first_son = NULL;
    head.last_brother = NULL;
    head.next_brother = NULL;  
    head.kind = Menu_Folder;
    head.name = "Menu";
    head.sons = 0;
    head.No = 0;

    Menu_Item *folder1 = dynamicCreate_Menu_Folder(&head, "PARAM");
    Menu_Item *folder2 = dynamicCreate_Menu_Folder(&head, "DISPLAY");
    Menu_Item *folder3 = dynamicCreate_Menu_Folder(&head, "SPEED");
    Menu_Item *folder4 = dynamicCreate_Menu_Folder(&head, "TASK1");
    Menu_Item *folder5 = dynamicCreate_Menu_Folder(&head, "TEST");
    Menu_Item *folder6 = dynamicCreate_Menu_Folder(&head, "INS");

    //数量---[40/256]

    //菜单1---13
    dynamicCreate_Menu_Number(folder1, "CloseLoop", &motorStr.CloseLoop, bool_box); 

    dynamicCreate_Menu_Number(folder1, "angle_v.Kp",&angle_v.Kp, float_box);
    dynamicCreate_Menu_Number(folder1, "angle.Kp",&angle.Kp, float_box);
    dynamicCreate_Menu_Number(folder1, "speed.Kp",&speed.Kp, float_box);
    dynamicCreate_Menu_Number(folder1, "turn_v.Kp",&turn_v.Kp, float_box);
    dynamicCreate_Menu_Number(folder1, "turn.Kp",&turn.Kp, float_box);
    dynamicCreate_Menu_Number(folder1, "bridge.Kp",&bridge.Kp, float_box);

    dynamicCreate_Menu_Number(folder1, "angle_v.Kd",&angle_v.Kd, float_box);
    dynamicCreate_Menu_Number(folder1, "angle.Kd",&angle.Kd, float_box);
    dynamicCreate_Menu_Number(folder1, "speed.Kd",&speed.Kd, float_box);
    dynamicCreate_Menu_Number(folder1, "turn_v.Kd",&turn_v.Kd, float_box);
    dynamicCreate_Menu_Number(folder1, "turn.Kd",&turn.Kd, float_box);
    dynamicCreate_Menu_Number(folder1, "bridge.Kd",&bridge.Kd, float_box);

    //菜单2---11
    dynamicCreate_Menu_Number(folder2, "INS",&displaystr.Ins, bool_box);
    dynamicCreate_Menu_Number(folder2, "RTS",&displaystr.Rts, bool_box);
    dynamicCreate_Menu_Number(folder2, "Pid",&displaystr.Pid, bool_box);
    dynamicCreate_Menu_Number(folder2, "Speed",&displaystr.Speed, bool_box);
    dynamicCreate_Menu_Number(folder2, "Motor",&displaystr.Motor, bool_box);
    dynamicCreate_Menu_Number(folder2, "Imu",&displaystr.Imu, bool_box);
    dynamicCreate_Menu_Number(folder2, "Wmc",&displaystr.Wmc, bool_box);
    dynamicCreate_Menu_Number(folder2, "Jump",&displaystr.Jump, bool_box);
    dynamicCreate_Menu_Number(folder2, "Bridge",&displaystr.Bridge, bool_box);
    dynamicCreate_Menu_Number(folder2, "Shoulder",&displaystr.Shoulder, bool_box);
    dynamicCreate_Menu_Number(folder2, "Battery",&displaystr.Battery, bool_box);

    //菜单3---7
    dynamicCreate_Menu_Number(folder3, "target",&speedctrl.target, float_box);
    dynamicCreate_Menu_Number(folder3, "straight1",&speedctrl.straight1, float_box);
    dynamicCreate_Menu_Number(folder3, "straight2",&speedctrl.straight2, float_box);
    dynamicCreate_Menu_Number(folder3, "straight3",&speedctrl.straight3, float_box);
    dynamicCreate_Menu_Number(folder3, "slalom",&speedctrl.slalom, float_box);
    dynamicCreate_Menu_Number(folder3, "bridge",&speedctrl.bridge, float_box);
    dynamicCreate_Menu_Number(folder3, "shoulder",&speedctrl.shoulder, float_box);

    //菜单4---3
    dynamicCreate_Menu_Number(folder4, "start",&rtsStr.enable, bool_box);

    dynamicCreate_Menu_Number(folder4, "cone",&rtsStr.cone, uint8_box);
    dynamicCreate_Menu_Number(folder4, "save",&flashStr.sub1_save, bool_box);
    
    

    //菜单5---4
    dynamicCreate_Menu_Number(folder5, "spin",&spin_enable, bool_box);
    dynamicCreate_Menu_Number(folder5, "jump",&jumpStr.enable, bool_box);
    dynamicCreate_Menu_Number(folder5, "shoulder",&shoulderStr.enable, bool_box);
    dynamicCreate_Menu_Number(folder5, "bridge",&bridgeStr.enable, bool_box);

    //菜单6---1
    dynamicCreate_Menu_Number(folder6, "INS_rts",&INS_rtsStr.enable, bool_box);

    //菜单7---1
    dynamicCreate_Menu_Number(&head, "test",&test, uint16_box);

    key = head.first_son;
}

/**
* @brief        菜单光标显示
* @param       
* @ref
* @author       NaiNong
* @note
**/
void show_key(void)
{
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0;i < h->sons; i++)
    {
        if (s == key)
        {
            ips200_show_string(8*0, 16*i, "->");
        }
        else
        {
            ips200_show_string(8*0, 16*i,"  ");
        }
        s = s->next_brother;
    }
}

/**
* @brief        菜单数值显示
* @param       
* @ref
* @author       NaiNong
* @note
**/
void show_number(void)
{
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0; i < h->sons; i++)
    {
        if(s->select)
            ips200_show_char(100, i*16, '[');     
        else
            ips200_show_char(100, i*16, ' ');     
        
        switch (s->kind)
        {
            case Menu_Folder:
            {
                ips200_show_char(120, i*16, '*');
                ips200_show_int(130, i*16, s->sons, 2);   
                break;
            }
            case bool_box:
            {
                if(*(bool *)s->data == true)
                    ips200_show_char(120, i*16, 'Y');     
                else
                    ips200_show_char(120, i*16, 'N');     
                break;
            }
            case int_box:
            {
                ips200_show_int(120, i*16, *(int *)s->data, 5);   
                break;
            }
            case float_box:
            {
                ips200_show_float(120, i*16, *(float *)s->data, 4, 3);  
                break;
            }
            case uint8_box:
            {
                ips200_show_int(120, i*16, *(uint8_t *)s->data, 5);   
                break;
            }
            case int8_box:
            {
                ips200_show_int(120, i*16, *(int8_t *)s->data, 5);   
                break;
            }
            case uint16_box:
            {
                ips200_show_int(120, i*16, *(uint16_t *)s->data, 5);   
                break;
            }
            case int16_box:
            {
                ips200_show_int(120, i*16, *(int16_t *)s->data, 5);   
                break;
            }
            case uint32_box:
            {
                ips200_show_int(120, i*16, *(uint32_t *)s->data, 5);   
                break;
            }
            case int32_box:
            {
                ips200_show_int(120, i*16, *(int32_t *)s->data, 5);   
                break;
            }
            default:
                break;
        }

        s = s->next_brother;
    }
}

/**
* @brief        菜单步进值显示
* @param       
* @ref
* @author       NaiNong
* @note
**/
void show_Setup(void)
{   
    ips200_show_string(8 * 10, 16 * 19,"Step-->");
    ips200_show_float(8 * 18, 16 * 19, SetupNumber[SetupIndex], 4, 3);   
}

/**
* @brief        菜单名称显示
* @param       
* @ref
* @author       NaiNong
* @note
**/
void show_name(void)
{       
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0; i < h->sons; i++)
    {
        ips200_show_string(8*2, 16*i, s->name);
        s = s->next_brother;
    }  
}

/**
* @brief        菜单显示
* @param       
* @ref
* @author       NaiNong
* @note
**/
void Menu_Show(void)
{
    show_key();
    show_name();
    show_Setup();
    show_number();
}