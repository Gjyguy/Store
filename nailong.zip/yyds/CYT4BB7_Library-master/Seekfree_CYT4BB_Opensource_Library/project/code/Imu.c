#include "Imu.h"

/**
* @brief       陀螺仪初始化
* @param
* @ref
* @author       NaiNong
* @note
**/
void Imu_Init(void)
{
    imu660rc_init(IMU660RC_QUARTERNION_120HZ);
}

/**
* @brief       陀螺仪数据处理
* @param
* @ref
* @author       NaiNong
* @note
**/
void Imu_Handle(void)
{
    imu660rc_roll += 180;

    if (imu660rc_roll > 180) 
        imu660rc_roll -= 360;

    if (imu660rc_yaw > 180) 
        imu660rc_yaw -= 360;
}

/**
* @brief       陀螺仪数据显示
* @param
* @ref
* @author       NaiNong
* @note
**/
void Imu_Show(void)
{
    ips200_show_string(8 * 8, 16 * 0, "[IMU DISPLAY]");

    ips200_show_string(8 * 0, 16 * 1, "pitch:");
    ips200_show_float(8 * 15, 16 * 1,imu660rc_pitch, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 2, "yaw:");
    ips200_show_float(8 * 15, 16 * 2,imu660rc_yaw, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 3, "roll:");
    ips200_show_float(8 * 15, 16 * 3,imu660rc_roll, 3, 2); 

    ips200_show_string(8 * 0, 16 * 4, "gyro_x:");
    ips200_show_float(8 * 15, 16 * 4,imu660rc_gyro_x, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 5, "gyro_y:");
    ips200_show_float(8 * 15, 16 * 5,imu660rc_gyro_y, 3, 2); 
    
    ips200_show_string(8 * 0, 16 * 6, "gyro_z:");
    ips200_show_float(8 * 15, 16 * 6,imu660rc_gyro_z, 3, 2); 
}