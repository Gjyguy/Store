#ifndef BATTERY_H
#define BATTERY_H

#include "zf_common_headfile.h"

#define BATTERY_PORT        (ADC0_CH21_P07_5)           // 电压检测端口

#define BATTERY_MAX         (12.6)                      // 电池最高电压12.6v 
#define BATTERY_MIN         (11.6)                      // 电池最低电压11.6v
#define BATTERY_REF         (3.3)                       // 参考电压3.3v
#define BATTERY_RES         (1023)                      // ADC分辨率10bit 1023
#define BATTERY_R1          (200)                       // 电阻R1的阻值200k
#define BATTERY_R2          (20)                        // 电阻R2的阻值20k

#define BATTERY_COUNT       (5)                         // 均值滤波次数
#define BATTERY_OFFSET      (0)                         // 检测电压偏移量

extern float battery_percent;                           // 电池电压百分比
extern float battery;                                   // 电池实际电压
extern uint16 battery_adc;                              // ADC采集的原始值

//外部函数声明
void Battery_Init(void);                                // 电池检测电压ADC初始化
void Battery_Calculate(void);                           // 电池电压计算
void Battery_Show(void);                                // 电池电压显示

#endif