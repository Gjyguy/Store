#ifndef BRC_H
#define BRC_H

#include "zf_common_headfile.h"

typedef enum {
    STAIRS = 0,             //三级台阶和陡坡
    BUMP,                   //颠簸路段
    BRIDGE,                 //交替单边桥
    GRASS,                  //草地路段
}Brc_Step;

typedef enum {
    JUMP_NONE = 0,          // 空闲
    JUMP_WAIT,              // 等待
    JUMP_PUSH,              // 蹬腿
    JUMP_FOLD,              // 收腿
    JUMP_EXTEND,            // 伸腿
    JUMP_CUSHION,           // 缓冲
    JUMP_EXIT,              // 结束
}Jump_Step;

typedef enum {
    BRIDGE_NONE = 0,        // 无单边桥
    BRIDGE_ENTER,           // 进入单边桥
    BRIDGE_EXIT,            // 退出单边桥
}Bridge_Step;

typedef enum {
    SHOULDER_NONE = 0,      // 无路肩
    SHOULDER_ENTER,         // 进入路肩
    SHOULDER_EXIT,          // 退出路肩
}Shoulder_Step;

typedef struct {
    bool enable; 
    float angle;
    uint8_t count;
    uint16_t jump_count;
    uint16_t wait_time;
    uint16_t jump_time;
    uint16_t fold_time;
    uint16_t extend_time;
    uint16_t cushion_time;
    uint16_t exit_time;
}JumpStruct;

typedef struct {
    bool enable;
    uint16_t count;        
    float height_left;
    float height_right;
    float angle;
    float height; 
}BridgeStruct;

typedef struct {
    bool enable;
    float angle;
    float height; 
}ShoulderStruct;

extern Jump_Step jump_step;
extern JumpStruct jumpStr;

extern Bridge_Step bridge_step;
extern BridgeStruct bridgeStr;

extern Shoulder_Step shoulder_step;
extern ShoulderStruct shoulderStr;

//颠簸路段相关函数声明
void Brc_process(void);

//跳跃相关函数声明
void Jump_Init(void);
void Jump_Timer(void);
void Jump_control(void);
void Jump_Show(void);

//单边桥相关函数声明
void Bridge_control(void);
void Bridge_Show(void);

//路肩相关函数声明
void Shoulder_control(void);
void Shoulder_Show(void);

#endif