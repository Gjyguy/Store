#ifndef PIT_H
#define PIT_H

#include "zf_common_headfile.h"

/**
* @brief    定时中断相关
**/
typedef struct {
    volatile uint16 Counter_1ms;                     //1ms计数器
    volatile uint16 Counter_5ms;                     //5ms计数器
    volatile uint16 Counter_10ms;                    //10ms计数器
}PitStruct;

extern PitStruct pitStr;

//外部函数声明
void Pit_Init(void);        //定时中断初始化
void Pit_1ms(void);
void Pit_5ms(void);
void Pit_10ms(void);

#endif