#include "Key.h"

KeyStruct Key1;
KeyStruct Key2;
KeyStruct Key3;
KeyStruct Key4;
KeyStruct Key5;

/**
* @brief        Key外设初始化
* @param
* @ref
* @author       NaiNong
* @note         外设：按键 x5 
**/
void Key_Init(void)
{
    gpio_init(KEY1, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY2, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY3, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY4, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY5, GPI,GPIO_HIGH, GPI_PULL_UP); 
    
    Key1.status = KEY1_GET;
    Key2.status = KEY2_GET;
    Key3.status = KEY3_GET;
    Key4.status = KEY4_GET;
    Key5.status = KEY5_GET;
}

/**
* @brief        Key状态获取与处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键 x5 
**/
void Key_Handle(void)
{
    Key1.last_status = Key1.status;
    Key2.last_status = Key2.status;
    Key3.last_status = Key3.status;
    Key4.last_status = Key4.status;
    Key5.last_status = Key5.status;

    Key1.status = KEY1_GET;
    Key2.status = KEY2_GET;
    Key3.status = KEY3_GET;
    Key4.status = KEY4_GET;
    Key5.status = KEY5_GET;

    if(Key1.last_status && !Key1.status)        Key1.state = KEY_PRESSED;    
    else if(Key2.last_status && !Key2.status)   Key2.state = KEY_PRESSED;
    else if(Key3.last_status && !Key3.status)   Key3.state = KEY_PRESSED;
    else if(Key4.last_status && !Key4.status)   Key4.state = KEY_PRESSED;
    else if(Key5.last_status && !Key5.status)   Key5.state = KEY_PRESSED;

    Key1_Handle();
    Key2_Handle();
    Key3_Handle();
    Key4_Handle();
    Key5_Handle();
}

/**
* @brief        按键1状态处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键1
**/
void Key1_Handle(void)
{
    if(Key1.state == KEY_PRESSED)
    {
        Key1.state = KEY_RELEASED;

        if(key->select == false)
            key_quit();
        else
            key_SetupCtrl_Sub();
            //key_SetupCtrl_Sub();
    }
}

/**
* @brief        按键2状态处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键2
**/
void Key2_Handle(void)
{
    if(Key2.state == KEY_PRESSED)
    {
        Key2.state = KEY_RELEASED; 

        switch (key->kind)
        {
            case Menu_Folder:
                key_enter();
                break;
            default:
                key_select();
                break;
        }
    }
}

/**
* @brief        按键3状态处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键3
**/
void Key3_Handle(void)
{
    if(Key3.state == KEY_PRESSED)
    {
        Key3.state = KEY_RELEASED;
        if(INS_rtsStr.enable)
        {
            INS_rtsStr.save = true;
        }
        
        //Buzzer_Enable(BuzzerDing);
    }
}

/**
* @brief        按键4状态处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键4
**/
void Key4_Handle(void)
{
    if(Key4.state == KEY_PRESSED)
    {
        Key4.state = KEY_RELEASED;

        if (key->select == false)
            key_up();
        else
            key_plus();
    }
}

/**
* @brief        按键5状态处理
* @param
* @ref
* @author       NaiNong
* @note         外设：按键5
**/
void Key5_Handle(void)
{
    if(Key5.state == KEY_PRESSED)
    {
        Key5.state = KEY_RELEASED;

        if (key->select == false)
            key_down();
        else
            key_sub();
    }
}

/**
* @brief        菜单上移
* @param
* @ref
* @author       NaiNong
* @note         外设：按键4
**/
void key_up(void)
{
    if(key->last_brother != NULL){
        key = key->last_brother;
    } else {  
        while (key->next_brother != NULL) {
            key = key->next_brother;
        }
    }
}

/**
* @brief        菜单下移
* @param
* @ref
* @author       NaiNong
* @note         外设：按键5
**/
void key_down(void)
{
    if (key->next_brother != NULL) {
        key = key->next_brother; 
    } else {
        while (key->last_brother != NULL) {
            key = key->last_brother;
        }
    }
}

/**
* @brief        菜单进入
* @param
* @ref
* @author       NaiNong
* @note         外设：按键2
**/
void key_enter(void)
{
    if (key->sons > 0)
    {
        key = key->first_son;
        ips200_clear();
    }
}

/**
* @brief        菜单退出
* @param
* @ref
* @author       NaiNong
* @note         外设：按键1
**/
void key_quit(void)
{
    if (key->father->father != NULL)
    {
        key = key->father;
        ips200_clear();
    } 
}

/**
* @brief        菜单选择/调参
* @param
* @ref
* @author       NaiNong
* @note         外设：按键2
**/
void key_select(void)
{
    if (key->kind != Menu_Folder)
        key->select =! key->select;
}

/**
* @brief        菜单步进值增加
* @param
* @ref
* @author       NaiNong
* @note         外设：按键1
**/
void key_SetupCtrl_Plus(void)
{
    SetupIndex = (SetupIndex + 1) % SETUP_LEN;
}

/**
* @brief        菜单步进值减少
* @param
* @ref
* @author       NaiNong
* @note         外设：按键1
**/
void key_SetupCtrl_Sub(void)
{
    SetupIndex = (SetupIndex - 1 + SETUP_LEN) % SETUP_LEN;
}

/**
* @brief        菜单数值增加
* @param
* @ref
* @author       NaiNong
* @note         外设：按键4
**/
void key_plus(void)
{
    switch (key->kind)
    {
        case bool_box:
        {
            *(bool *)key->data = true;
            break;
        }
        case int_box:
        {
            *(int *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case float_box:
        {
            *(float *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case uint8_box:
        {
            *(uint8_t *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case int8_box:
        {
            *(int8_t *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case uint16_box:
        {
            *(uint16_t *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case int16_box:
        {
            *(int16_t *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case uint32_box:
        {
            *(uint32_t *)key->data += SetupNumber[SetupIndex];
            break;
        }
        case int32_box:
        {
            *(int32_t *)key->data += SetupNumber[SetupIndex];
            break;
        }        
        default:
            break;
    }
}

/**
* @brief        菜单数值减少
* @param
* @ref
* @author       NaiNong
* @note         外设：按键5
**/
void key_sub(void)
{
    switch (key->kind)
    {
        case bool_box:
        {
            *(bool *)key->data = false;
            break;
        }
        case int_box:
        {
            *(int *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case float_box:
        {
            *(float *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case uint8_box:
        {
            *(uint8_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case int8_box:
        {
            *(int8_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case uint16_box:
        {
            *(uint16_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case int16_box:
        {
            *(int16_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case uint32_box:
        {
            *(uint32_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }
        case int32_box:
        {
            *(int32_t *)key->data -= SetupNumber[SetupIndex];
            break;
        }        
        default:
            break;
    }
}