#include "Display.h"

DisplayEnum displayState;         //当前显示状态
DisplayEnum lastDisplayState;     //上一次显示状态
DisplayStruct displaystr;         //显示状态结构体

/**
* @brief        IPS显示屏初始化
* @param
* @ref
* @author       NaiNong
* @note
**/
void Display_Init(void)
{
    ips200_init(IPS200_TYPE_SPI);
    ips200_set_font(IPS200_8X16_FONT);
    ips200_full(RGB565_CYAN);
    ips200_set_color(RGB565_BLACK,RGB565_CYAN);

    displayState = DISPLAY_MENU;
    lastDisplayState = DISPLAY_MENU;

    displaystr.enable = true;
    displaystr.Ins = false;
    displaystr.Rts = false;
    displaystr.Battery = false;
    displaystr.Speed = false;
    displaystr.Imu = false;
    displaystr.Motor = false;
    displaystr.Pid = false;
    displaystr.Wmc = false;
    displaystr.Jump = false;
    displaystr.Bridge = false;
    displaystr.Shoulder = false;
}

/**
* @brief        IPS显示屏显示
* @param
* @ref
* @author       NaiNong
* @note
**/
void Display_Show(void)
{

    if(displaystr.Ins){
        displayState = DISPLAY_INS;
    }else if(displaystr.Rts){
        displayState = DISPLAY_RTS;
    }else if(displaystr.Battery){
        displayState = DISPLAY_BATTERY;
    }else if(displaystr.Speed){
        displayState = DISPLAY_SPEED;
    }else if(displaystr.Imu){
        displayState = DISPLAY_IMU;
    }else if(displaystr.Motor){
        displayState = DISPLAY_MOTOR;
    }else if(displaystr.Pid){
        displayState = DISPLAY_PID;
    }else if(displaystr.Wmc){
        displayState = DISPLAY_WMC;
    }else if(displaystr.Jump){
        displayState = DISPLAY_JUMP;
    }else if(displaystr.Bridge){
        displayState = DISPLAY_BRIDGE;
    }else if(displaystr.Shoulder){
        displayState = DISPLAY_SHOULDER;
    }else
        displayState = DISPLAY_MENU;

    if (displayState != lastDisplayState) {
        lastDisplayState = displayState;  
        ips200_clear(); 
    }

    if(displayState != DISPLAY_MENU){
        ips200_show_string(8 * 5, 16 * 19, "press key5 to exit");
    }
    

    switch (displayState) 
    {
        case DISPLAY_INS:
            Ins_Show();
            break;
        case DISPLAY_RTS:
            Rts_Show();
            break;
        case DISPLAY_MENU:
            Menu_Show();
            break;
        case DISPLAY_SPEED:
            Speed_Show();
            break;
        case DISPLAY_BATTERY:
            Battery_Show();
            break;
        case DISPLAY_IMU:
            Imu_Show();
            break;
        case DISPLAY_MOTOR:
            Motor_Show();
            break;
        case DISPLAY_PID:
            PID_Show();
            break;
        case DISPLAY_WMC:
            Wmc_Show();
            break;
        case DISPLAY_JUMP:
            Jump_Show();
            break;
        case DISPLAY_BRIDGE:
            Bridge_Show();
            break;
        case DISPLAY_SHOULDER:
            Shoulder_Show();
            break;
        default:
            // 无显示
            break;
    }

}