#ifndef BATTERY_H
#define BATTERY_H

#include "zf_common_headfile.h"
#define Voltage_offset 0.10

extern float battery;
extern uint16 battery_data;
void Battery_init(void);
void Battery_get(void);
void Battery_calculate(void); 

#endif