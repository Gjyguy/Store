#ifndef Key_H
#define Key_H

#include "zf_common_headfile.h"

#define KEY1            (P20_0)
#define KEY2            (P20_1)
#define KEY3            (P20_2)
#define KEY4            (P20_3)

typedef struct {
        uint8 key1_flag;
        uint8 key2_flag;
        uint8 key3_flag;
        uint8 key4_flag;
        
        uint8 key1_status;
        uint8 key2_status;
        uint8 key3_status;
        uint8 key4_status;

        uint8 key1_last_status;
        uint8 key2_last_status;
        uint8 key3_last_status;
        uint8 key4_last_status;   
}keyboard;

extern keyboard Key;

void Key_Init(void);
void Key_Handle(void);

void key_up(void);
void key_down(void);
void key_enter(void);
void key_quit(void);
void key_select(void);
void Key1(void);
void Key2(void);
void Key3(void);
void Key4(void);
#endif