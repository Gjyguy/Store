#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include "zf_common_headfile.h"

typedef enum MENU_KIND {
    Menu_Folder = 0,
    int32_box,
    uint32_box,
    int16_box,
    uint16_box,
    int8_box,
    uint8_box,
    float_box,
    bool_box,
}MENU_KIND;

typedef struct Menu_Item {
    const char* name;
    void* data;         //ָ���ű���������
    MENU_KIND kind;     //��¼�ڵ�����
    
    uint8_t sons;       //��¼�ӽڵ�����
    uint8_t No;         //��¼��ǰ�Ǹ��ڵ�ڼ�����Ա

    uint8_t int_step;
    float float_step;

    bool select;

    struct Menu_Item *father;
    struct Menu_Item *first_son;
    struct Menu_Item *next_brother;
    struct Menu_Item *last_brother;
}Menu_Item;

extern Menu_Item head;
extern Menu_Item *key;

void Create_Menu_Item(Menu_Item *father, Menu_Item *me, const char name[],void *data, MENU_KIND kind);

#endif