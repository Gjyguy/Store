#include "Battery.h"

uint16 battery_data;
float battery;

void Battery_init(void)
{
    adc_init(ADC0_CH21_P07_5, ADC_10BIT);  
    Battery_calculate();   
}


void Battery_get(void)
{
    battery_data= adc_convert(ADC0_CH21_P07_5);
}

void Battery_calculate(void) 
{
    battery_data=adc_mean_filter_convert(ADC0_CH21_P07_5, 5); 
    battery=(float)battery_data/1023*3.3*(200+20)/20+Voltage_offset;
}