#include "Buzzer.h"

BuzzerStruct buzzerStr;

/**
* @brief        Buzzer�����ʼ��
* @param
* @ref
* @author       NaiNong
* @note         ���裺������ 
**/
void Buzzer_Init(void)
{
    gpio_init(P19_4, GPO, 0, GPO_PUSH_PULL); 
    
    buzzerStr.Counter = 0;        //������
    buzzerStr.Cut = 0;            //���ʱ��
    buzzerStr.Times = 0;          //���д���
    buzzerStr.Enable = false;     //ʹ�� 
}

/**
* @brief        Buzzer�߳̿�����
* @param
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Timer(void)
{
    //����������
    if(buzzerStr.Enable)
    {
        buzzerStr.Counter++;

        if(buzzerStr.Counter>buzzerStr.Cut)
            buzzerStr.Counter = buzzerStr.Cut;
    }
}

/**
* @brief        Buzzer�߼���������
* @param
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Handle(void)
{
    //����������
    if(buzzerStr.Enable && !buzzerStr.Silent)
    {
        if(buzzerStr.Times<=0)
        {
            BUZZER_OFF;
            buzzerStr.Enable = false;
            return;
        }
        else if(buzzerStr.Cut <= buzzerStr.Counter)
        {
            BUZZER_REV;
            buzzerStr.Times--;
            buzzerStr.Counter = 0;
        }
    }
    else
    {
        BUZZER_OFF;
    }  
}

/**
* @brief        ������ʹ��
* @param        buzzer������������ģʽ
* @ref
* @author       NaiNong
* @note
**/
void Buzzer_Enable(BuzzerEnum buzzer)
{
    switch(buzzer)
    {
        case BuzzerOk:
            buzzerStr.Cut = 70;         //70ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 4;
            break;

        case BuzzerWarning:
            buzzerStr.Cut = 100;        //100ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 10;
            break;

        case BuzzerSysStart:
            buzzerStr.Cut = 60;         //60ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 6;
            break;

        case BuzzerDing:
            buzzerStr.Cut = 30;         //30ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 2;
            break;

        case BuzzerFinish:
            buzzerStr.Cut = 200;        //200ms
            buzzerStr.Enable = true;
            buzzerStr.Times = 6;
            break;
    }
    buzzerStr.Counter = 0;
}
