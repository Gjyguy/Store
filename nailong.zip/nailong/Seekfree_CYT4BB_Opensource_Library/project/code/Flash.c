#include "Flash.h"

bool flash = false;
uint8 check = 0;

void flash_read(void)
{
    check = flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM);
     
    flash_read_page_to_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM, 2);        // �����ݴ� flash ��ȡ��������
    
    test=flash_union_buffer[0].int32_type;
    Ins.size_one=flash_union_buffer[1].int32_type;
      
    flash_buffer_clear();
}

void flash_write(void)
{
    if(flash)
    {
        if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM))
        {
            flash_erase_page(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM);
        }
        
        flash_buffer_clear(); 
 
        flash_union_buffer[0].int32_type = test;
        flash_union_buffer[1].int32_type = Ins.size_one;
        
        flash_write_page_from_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_PARAM, 2);
    
        check++;
        
        flash = false;
    }
}

