#ifndef PID_H
#define PID_H

#include "zf_common_headfile.h"

/*
typedef struct {
    float Kp;              // ����ϵ��
    float Ki;              // ����ϵ��
    float Kd;              // ΢��ϵ��

    float ref;             // Ŀ��ֵ
    float fdb;             // ����ֵ
    float err;             // ��ǰ���
    float err_prev;        // ��һʱ�����
    float err_sum;         // ������

    float out;             // PID ���
    float out_max;         // ����޷�
    float integral_max;    // �����޷�
} PIDStruct;

extern PIDStruct Ls_pid;
extern PIDStruct Rs_pid;
extern PIDStruct Ag_pid;

// PID
void PID_Init(PIDStruct *pid, float Kp, float Ki, float Kd, float out_max, float integral_max);
void PID_Reset(PIDStruct *pid);

//�ٶȻ�
//float PID_Speed(PIDStruct *pid, float ref, float fdb);
//�ǶȻ�
//float PID_Angle(PIDStruct *pid, float ref, float fdb);


*/
typedef struct
{
    float kp, ki, kd, kd3,kp3;
    float error, lastError,last_last_Error,error1;
    float integral, maxIntegral;
    float output, maxOutput;
    float now_feedback,last_feedback;
    float K;
}PID;

extern PID Angle;
extern PID Angle_v;
extern PID v;
extern PID turn;
extern PID yaw_balance;

extern int16 Speed_Goal;
extern int16 Speed_now;
extern int16 Speed_total;
extern bool Go;

void isr_control(void);

extern void PID_Init(PID *pid, float p, float i, float d, float maxI, float maxOut,float K);
extern void PID_Init3(PID *pid, float p, float i, float d, float kp3, float kd3,float maxI, float maxOut,float K);

extern void PID_Calc_v(PID *pid, float reference, float feedback);
extern void PID_Calc(PID *pid, float reference, float feedback);
#endif