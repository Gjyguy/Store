#include "Servo.h"

ServoStruct servoStr;

/**
* @brief        �����ʼ��
* @param        
* @ref
* @author       NaiNong
* @note
**/
void Servo_Init(void)
{
    pwm_init(SERVO_LU, FREQ, 4000);
    pwm_init(SERVO_LD, FREQ, 6000);
    pwm_init(SERVO_RU, FREQ, 5000);
    pwm_init(SERVO_RD, FREQ, 3000);
    
    servoStr.lu_pwm=4000;
    servoStr.ru_pwm=5000;
}

/**
* @brief        ������PWM����
* @param        pwm��-200~200
* @ref
* @author       NaiNong
* @note
**/
void SERVO_SetPwmValue(void)
{


    if(servoStr.lu_pwm < SERVO_PWM_MAX_R)
        servoStr.lu_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.lu_pwm > SERVO_PWM_MAX_L)
        servoStr.lu_pwm = SERVO_PWM_MAX_L;

    if(servoStr.ru_pwm < SERVO_PWM_MAX_R)
        servoStr.ru_pwm = SERVO_PWM_MAX_R;
    else if(servoStr.ru_pwm > SERVO_PWM_MAX_L)
        servoStr.ru_pwm = SERVO_PWM_MAX_L;

    pwm_set_duty(SERVO_LU,servoStr.lu_pwm);
    pwm_set_duty(SERVO_RU,servoStr.ru_pwm);
}