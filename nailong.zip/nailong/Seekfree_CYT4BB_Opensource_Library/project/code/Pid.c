#include "Pid.h"
/*
PIDStruct Ls_pid;
PIDStruct Rs_pid;
PIDStruct Ag_pid;

void PID_Init(PIDStruct *pid, float Kp, float Ki, float Kd, float out_max, float integral_max)
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    
    pid->out_max = out_max;
    pid->integral_max = integral_max;
  
    PID_Reset(pid);
}

void PID_Reset(PIDStruct *pid)
{
    pid->ref = 0;
    pid->fdb = 0;
    pid->err = 0;
    pid->err_prev = 0;
    pid->err_sum = 0;
    pid->out = 0;
}



float PID_Speed(PIDStruct *pid, float ref, float fdb)
{
    //�������
    pid->err = ref - fdb;   //�������
    pid->err_prev = pid->err;
    
    pid->out += pid->Kp * (pid->err- pid->err_prev)+ pid->Ki * pid->err;
    
    if(pid->out>pid->out_max)
    {
        pid->out=pid->out_max;
    }
    else if(pid->out<-pid->out_max)
    {
        pid->out=-pid->out_max;
    }

    return pid->out;
}

float PID_Angle(PIDStruct *pid, float ref, float fdb)
{
    //�������
    pid->err = ref - fdb;   //�������
    pid->err_prev = pid->err;
    
    pid->out = pid->Kp * pid->err + pid->Ki * (pid->err- pid->err_prev);
    
        if(pid->out>pid->out_max)
    {
        pid->out=pid->out_max;
    }
    else if(pid->out<-pid->out_max)
    {
        pid->out=-pid->out_max;
    }

    return pid->out;
}
*/

PID Angle={0};
PID Angle_v={0};
PID v={0};
PID turn={0};
PID yaw_balance={0};

int16 Speed_Goal=0;
int16 Speed_now=0;
int16 Speed_total=0;

bool Go=false;

void PID_Init(PID *pid, float p, float i, float d, float maxI, float maxOut,float K)
{
    pid->kp = p;
    pid->ki = i;
    pid->kd = d;
    pid->maxIntegral = maxI;//��������
    pid->maxOutput = maxOut;//�������
    pid->K =K;
}

void PID_Init3(PID *pid, float p, float i, float d,float kp3, float kd3, float maxI, float maxOut, float K)
{
    pid->kp = p;
    pid->ki = i;
    pid->kd = d;
    pid->maxIntegral = maxI;//��������
    pid->maxOutput = maxOut;//�������
    pid->kp3 =kp3;
    pid->kd3 =kd3;
    pid->K =K;
}

void PID_Calc_v(PID *pid, float reference, float feedback)
{
    pid->lastError = pid->error; //�������
    pid->error = reference - feedback; //�������
//       pid->maxIntegral=pid->error*0.01;
    float dout = pid->K*(pid->error - pid->lastError) * pid->kd;//����΢��

    float pout = pid->K*pid->error * pid->kp;//�������

    pid->integral += pid->K*(pid->error * pid->ki);//�������
/*�����޷�*/
    if(pid->integral > pid->maxIntegral) pid->integral = pid->maxIntegral;
    else if(pid->integral < -pid->maxIntegral) pid->integral = -pid->maxIntegral;

    pid->output = pout+dout + pid->integral;

    if(pid->output > pid->maxOutput) pid->output =   pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output = -pid->maxOutput;
}

void PID_Calc(PID *pid, float reference, float feedback)
{
    pid->lastError = pid->error; //�������
    pid->error = reference - feedback; //�������

    float dout = pid->K*(pid->error - pid->lastError) * pid->kd;//����΢��

    float pout = pid->K*pid->error * pid->kp;//�������

    pid->integral += pid->K*(pid->error * pid->ki);//�������
/*�����޷�*/
    if(pid->integral > pid->maxIntegral) pid->integral = pid->maxIntegral;
    else if(pid->integral < -pid->maxIntegral) pid->integral = -pid->maxIntegral;

    pid->output = pout+dout + pid->integral;

    if(pid->output > pid->maxOutput) pid->output =   pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output = -pid->maxOutput;
}
/*
void PID_Calc_Turn(PID *pid, float reference, float feedback)
{
    if(pid->kp<60)pid->kp=60;
    if(pid->kp>125)pid->kp=125;
    pid->lastError = pid->error; //�������
    pid->error = reference - feedback; //�������

    float dout = pid->K*(icm_data.gyro_y - gyro_y_last) * pid->kd;//����΢��
    float dout2 = pid->K*(pid->error - pid->lastError) * pid->maxIntegral;//����΢��
    float pout = pid->K*pid->error * pid->kp;//�������
    float pout2 = pid->K*icm_data.gyro_y * pid->ki;//�������


    pid->output = pout+dout + dout2+ pout2;
    gyro_y_last=icm_data.gyro_y;
    if(pid->output > pid->maxOutput) pid->output =   pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output = -pid->maxOutput;
}
*/
void isr_control(void)
{

}



