#include "Menu.h"

static Menu_Item menu_item_arr[MENU_MAX_SIZE];
static uint8_t menu_arr_index = 0;

int32 test = 10;
float test1 = 27.51;
bool test2 = false;

//�����ļ���
void Create_Menu_Folder(Menu_Item* father, Menu_Item* me, const char name[])
{
    Create_Menu_Item(father, me, name,NULL, Menu_Folder);
}

//�����ļ�
void Create_Menu_Number(Menu_Item* father, Menu_Item* me, const char name[],void *data, MENU_KIND kind)
{
    Create_Menu_Item(father, me, name, data, kind);
}

//��̬�����ļ���
Menu_Item* dynamicCreate_Menu_Folder(Menu_Item* father, const char name[])
{
    Menu_Item *me= &menu_item_arr[menu_arr_index++];

    Create_Menu_Item(father, me, name, NULL, Menu_Folder);

    return me;
}

//��̬�����ļ�
void dynamicCreate_Menu_Number(Menu_Item* father, const char name[], void* data, MENU_KIND kind)
{
    Menu_Item* me = &menu_item_arr[menu_arr_index++];

    Create_Menu_Item(father, me, name, data, kind);
}

void menu_init(void)
{
    head.data = NULL;
    head.father = NULL;
    head.first_son = NULL;
    head.last_brother = NULL;
    head.next_brother = NULL;
    head.kind = Menu_Folder;
    head.name = "Menu";
    head.int_step = 0;
    head.float_step = 0;

    Menu_Item *folder1 = dynamicCreate_Menu_Folder(&head, "folder1");
    Menu_Item *folder2 = dynamicCreate_Menu_Folder(&head, "folder2");

    dynamicCreate_Menu_Number(folder1, "servo",&servoStr.lu_pwm, int16_box);
    dynamicCreate_Menu_Number(folder1, "servo",&servoStr.ru_pwm, int16_box);
    dynamicCreate_Menu_Number(folder1, "Go", &Go, bool_box); 
    dynamicCreate_Menu_Number(folder1, "Collect", &Collect, bool_box); 
    dynamicCreate_Menu_Number(folder1, "Finsh", &Finsh, bool_box); 
    dynamicCreate_Menu_Number(folder1, "Read", &Read, bool_box); 
    dynamicCreate_Menu_Number(folder1, "Record", &Record, bool_box); 
        
    dynamicCreate_Menu_Number(folder2, "test", &test, int32_box);
    dynamicCreate_Menu_Number(folder2, "size", &Ins.size_one, int32_box);
    
    dynamicCreate_Menu_Number(&head, "flash", &flash, bool_box); 
    
    key = head.first_son;
}

void show_key(void)
{
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0;i < h->sons; i++)
    {
        if (s == key)
        {
            ips200_show_string(8*0, 16*i, "->");
        }
        else
        {
            ips200_show_string(8*0, 16*i,"  ");
        }
        s = s->next_brother;
    }
}

void show_number(void)
{
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0; i < h->sons; i++)
    {
        if(s->select)
            ips200_show_char(100, i*16, '[');     
        else
            ips200_show_char(100, i*16, ' ');     
        
        switch (s->kind)
        {
        case int32_box:
            ips200_show_int(120, i*16, *(int32_t *)s->data, 5);   
            break;
        case int16_box:
            ips200_show_int(120, i*16, *(int16_t *)s->data, 5);   
            break;
        case float_box:
            ips200_show_float(120, i*16, *(float *)s->data, 3, 2);  
            break;
        case bool_box:
            if(*(bool *)s->data == true)
                 ips200_show_char(120, i*16, 'Y');     
            else
                 ips200_show_char(120, i*16, 'N');     
            break;
        default:
            break;
        }

        s = s->next_brother;
    }
}

void menu_show(void)
{
    Menu_Item* h = key->father;
    Menu_Item* s = h->first_son;

    for (int i = 0; i < h->sons; i++)
    {
        ips200_show_string(8*2, 16*i, s->name);
        s = s->next_brother;
    }
    show_key();
    show_number();
}