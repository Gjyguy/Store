 #include "Key.h"

keyboard Key;

/**
* @brief        Key�����ʼ��
* @param
* @ref
* @author       NaiNong
* @note         ���裺���� X4
**/
void Key_Init(void)
{
    gpio_init(KEY1, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY2, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY3, GPI,GPIO_HIGH, GPI_PULL_UP); 
    gpio_init(KEY4, GPI,GPIO_HIGH, GPI_PULL_UP); 

    Key.key1_status=gpio_get_level(KEY1);
    Key.key2_status=gpio_get_level(KEY2);
    Key.key3_status=gpio_get_level(KEY3);
    Key.key4_status=gpio_get_level(KEY4);
}
    


/**
* @brief        Key��ȡ����״̬
* @param
* @ref
* @author       NaiNong
* @note         ���裺���� X4
**/
void Key_Handle(void)
{
    Key.key1_last_status=Key.key1_status;
    Key.key2_last_status=Key.key2_status;
    Key.key3_last_status=Key.key3_status;
    Key.key4_last_status=Key.key4_status;
    
    Key.key1_status=gpio_get_level(KEY1);
    Key.key2_status=gpio_get_level(KEY2);
    Key.key3_status=gpio_get_level(KEY3);
    Key.key4_status=gpio_get_level(KEY4);
    
    if(!Key.key1_status && Key.key1_last_status)        Key.key1_flag=1;
    else if(!Key.key2_status && Key.key2_last_status)   Key.key2_flag=1;
    else if(!Key.key3_status && Key.key3_last_status)   Key.key3_flag=1;
    else if(!Key.key4_status && Key.key4_last_status)   Key.key4_flag=1;
    
    Key1();
    Key2();
    Key3();
    Key4();
}

void key_down(void)
{
    if(key->next_brother!=NULL)
        key = key->next_brother;
}

void key_up(void)
{
    if (key->last_brother != NULL)
        key = key->last_brother;
}

void key_enter(void)
{
    if (key->sons > 0)
    {
        key = key->first_son;
        ips200_clear();
    }
}

void key_quit(void)
{
    if (key->father->father != NULL)
    {
        key = key->father;
        ips200_clear();
    }    
}

void key_select(void)
{
    if (key->kind != Menu_Folder)
        key->select =! key->select;
}


void key_plus(void)
{
    switch (key->kind)
    {
    case int32_box:
        *(int32_t*)key->data += 1;
        break;
    case int16_box:
        *(int16_t*)key->data += 100;
        break;
    case bool_box:
        *(bool *)key->data = true;
    default:
        break;
    }
}

void key_sub(void)
{
    switch (key->kind)
    {
    case int32_box:
        *(int32_t*)key->data -= 1;
        break;
    case int16_box:
        *(int16_t*)key->data -= 100;
        break;
    case bool_box:
        *(bool *)key->data = false;
        break;
    default:
        break;
    }
}

void Key1(void)
{
    if(Key.key1_flag)
    {
        Key.key1_flag=0;
        if(key->select == false)
            key_quit();
    }
}

void Key2(void)
{
    if(Key.key2_flag)
    {
        Key.key2_flag=0;
        switch (key->kind)
        {
          case Menu_Folder:
              key_enter();
              break;
          default:
              key_select();
              break;
        }
    }
}

void Key3(void)
{
    if(Key.key3_flag)
    {
        Key.key3_flag=0;
        if (key->select == false)
            key_down();
        else
            key_sub();//���κ���
    }
}

void Key4(void)
{
    if(Key.key4_flag)
    {
        Key.key4_flag=0;
        if (key->select == false)
            key_up();
        else
            key_plus();//���κ���
    }
}
 