#ifndef INS_H
#define INS_H

#include "zf_common_headfile.h"

#define NPS_GPS_Set_mileage 2000 //��̼�

typedef struct{
       int32 size_one;

       int16 distance_travelled;           //��̼���
       uint8 INS_page;
       float Angle_read;
       int32  Model;
       uint8  INS_End;
       uint8  open_nps_gps_read  ; 
       uint8  INS_cnt;
       uint8  INS_CNT;
       uint8  INS_GPS_DAQ_OPEN;
}INS;

extern INS Ins;
extern bool Collect;
extern bool Finsh;
extern bool Read;
extern bool Record;

extern int16 angle_cnt;
extern int32 size_cnt;
extern float angle_yaw[FLASH_PAGE_LENGTH];

extern void Ins_Collection(void);
extern void flash_write_ins(void);
extern void NPS_GPS_Reproduce(void);

#endif