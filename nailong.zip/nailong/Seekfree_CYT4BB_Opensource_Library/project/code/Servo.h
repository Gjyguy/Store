#ifndef SERVO_H
#define SERVO_H

#include "zf_common_headfile.h"

#define  SERVO_LU              (TCPWM_CH09_P05_0)                        //�������PWMͨ��
#define  SERVO_LD              (TCPWM_CH10_P05_1)                      
#define  SERVO_RU              (TCPWM_CH11_P05_2)    
#define  SERVO_RD              (TCPWM_CH12_P05_3)   

#define  FREQ                  (300)                                       //���Ƶ��





#define  SERVO_PWM_MAX_L                6000                        //�������ת�����ֵPWM
#define  SERVO_PWM_MAX_R                3000                        //�������ת�����ֵPWM
#define  SERVO_PWM_MIDDLE               4500   

/**
* @brief    ������
**/
typedef struct
{
    uint16_t lu_pwm;
    uint16_t ru_pwm;
    uint16_t ld_pwm;
    uint16_t rd_pwm;
}ServoStruct;

extern ServoStruct servoStr;

void Servo_Init(void);
void SERVO_SetPwmValue(void);
#endif
