#ifndef IPS_H
#define IPS_H

#include "zf_common_headfile.h"

void Ips_Init(void);
void Ips_Show(void);

extern const unsigned char gImage_nai[66960];
#endif
