#include "Linked_list.h"

Menu_Item head;
Menu_Item *key;

//��ʼ����Ա
void Create_Menu_Item(Menu_Item *father, Menu_Item *me, const char name[],void *data, MENU_KIND kind)
{
    if (father->kind != Menu_Folder) return;
   
    me->name = name;
    me->sons = 0;
    me->select = false;

    me->father = father;
    me->first_son = NULL;
    me->next_brother = NULL;
    me->last_brother = NULL;

    me->data = data;
    me->kind = kind;
    
    if (father->sons == 0)
    {
        father->first_son = me;
    }
    else
    {
        Menu_Item *p = father->first_son;
        while (p->next_brother != NULL)
            p = p->next_brother;

        p->next_brother = me;
        me->last_brother = p;
    }
    me->No = father->sons;
    father->sons++;
}