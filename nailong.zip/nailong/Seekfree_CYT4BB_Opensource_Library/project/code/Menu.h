#ifndef MENU_H
#define MENU_H

#include "zf_common_headfile.h"

#define MENU_MAX_SIZE       (64)

void menu_init(void);
void menu_show(void);

extern int32 test;
extern float test1;
extern bool test2;

#endif